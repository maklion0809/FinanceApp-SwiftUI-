//
//  UNLIMITApp.swift
//  UNLIMIT
//
//  Created by Тимофей on 07.06.2021.
//

import SwiftUI

@main
struct UNLIMITApp: App {
    
    @AppStorage("darkMode") var darkMode: Bool = false
        @AppStorage("system") var system: Bool = true
    
    @State private var showWallet = false

    var body: some Scene {
        WindowGroup {
            if UserDefaults.standard.string(forKey: "ChooseUser") != nil{
                if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
                    if let user = DatabaseManager.shared.getUser(id: userId){
                        if user.wallets.count != 0{
                            if let pin = UserDefaults.standard.bool(forKey: "PIN-code"){
                                if pin{
                                    Security().onAppear {
                                        ThemeManager.shared.handleTheme(darkMode: self.darkMode, system: self.system)
                                    }

                                }else{
                                    HomeView().onAppear {
                                        ThemeManager.shared.handleTheme(darkMode: self.darkMode, system: self.system)
                                    }
                                }
                            }
                        }else{
                            AddWallet(auto: true).onAppear {
                                ThemeManager.shared.handleTheme(darkMode: self.darkMode, system: self.system)
                            }
                        }
                    }
                }
            }else{
                ContentView().onAppear {
                    ThemeManager.shared.handleTheme(darkMode: self.darkMode, system: self.system)
                }
            }
        }
    }
}
