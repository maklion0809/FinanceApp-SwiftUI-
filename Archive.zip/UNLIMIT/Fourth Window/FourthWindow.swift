//
//  FourthWindow.swift
//  UNLIMITApp
//
//  Created by Тимофей on 27.04.2021.
//

import SwiftUI
import UserNotifications

struct FourthWindow: View{
    
    @ObservedObject var appSettingsVM: AppSettingsViewModel
    
    @State private var chooseTouchID = UserDefaults.standard.bool(forKey: "PIN-code")

    @State private var exitThisApp = false
    @State private var chooseRemind = false
    @State private var darkTheme = UserDefaults.standard.bool(forKey: "ColorApp")
    
    @State private var showingAddGolf = false
    @State private var showingAddDebt = false
    @State private var showingAddCategory = false
    
    @State private var showingHelpForUser = false
    
    @State var showConfirm = false
    
    @State var showConfirm1 = false //UserDefaults.standard.bool(forKey: "Remind")
    
    @State var showChangeSecurity = false

    
    var body: some View {
        
        NavigationView {
            ZStack{
                Color.primary_color.edgesIgnoringSafeArea(.all)
                
                VStack{
                    ScrollView(showsIndicators: false){
                        VStack{
                            
                            Image("setting").resizable().aspectRatio(contentMode: .fit).frame(width: 200, height: 200, alignment: .center)
                            
                            VStack(alignment: .leading, spacing: 15){
                                
                                Group{
                                    HStack{
                                        Text("Цель")
                                        Spacer()
                                        
                                        Button(action:{
                                            withAnimation{
                                                self.showingAddGolf = true
                                            }
                                        }){
                                            Image(systemName: "chevron.right").foregroundColor(.primary_color).font(.title3)
                                        }.padding(.all, 10).background(Color.primary_back).cornerRadius(10).fullScreenCover(isPresented: $showingAddGolf) {
                                            GoalView()
                                        }
                                    }
                                    
                                    Divider()
                                    
                                    HStack{
                                        Text("Долги")
                                        
                                        Spacer()
                                        
                                        Button(action:{
                                            withAnimation{
                                                self.showingAddDebt = true
                                            }
                                        }){
                                            Image(systemName: "chevron.right").foregroundColor(.primary_color).font(.title3)
                                        }.padding(.all, 10).background(Color.primary_back).cornerRadius(10).fullScreenCover(isPresented: $showingAddDebt) {
                                            DebtView()
                                        }
                                        
                                    }
                                    
                                    Divider()
                                    
                                    HStack{
                                        Text("Категории")
                                        Spacer()
                                        
                                        Button(action:{
                                            withAnimation{
                                                self.showingAddCategory = true
                                            }
                                        }){
                                            Image(systemName: "chevron.right").foregroundColor(.primary_color).font(.title3)
                                        }.padding(.all, 10).background(Color.primary_back).cornerRadius(10).fullScreenCover(isPresented: $showingAddCategory){
                                            CategoryView(viewModel: CategoryViewModel())
                                        }
                                    }
                                    
                                    Divider()
                                }
                                
                                Group{
                                    Toggle(isOn: $chooseRemind, label: {
                                        Text("Напомнить о внесении операции")
                                    }).toggleStyle(SwitchToggleStyle(tint: Color.primary_back)).onTapGesture {
                                        self.showConfirm1.toggle()
                                        UserDefaults.standard.setValue(showConfirm1, forKey: "Remind")
                                    }
                                    
                                    Toggle(isOn: $darkTheme, label: {
                                        Text("Включить темную тему")
                                    }).toggleStyle(SwitchToggleStyle(tint: Color.primary_back)).onTapGesture {
                                        self.darkTheme.toggle()
                                        appSettingsVM.handleTheme(darkMode: darkTheme, system: false)
                                        UserDefaults.standard.setValue(darkTheme, forKey: "ColorApp")
                                        UIApplication.shared.windows.first?.rootViewController?.view.overrideUserInterfaceStyle = UserDefaults.standard.bool(forKey: "ColorApp") ? .dark : .light
                                    }
                                    
                                    Divider()
                                }
                                Group{
                                    Text("PIN-код").foregroundColor(.gray)
                                    
                                    HStack{
                                        Text("Изменить PIN-код")
                                        Spacer()
                                        
                                        Button(action:{
                                            self.showChangeSecurity.toggle()
                                        }){
                                            Image(systemName: "chevron.right").foregroundColor(.primary_color).font(.title3)
                                        }.padding(.all, 10).background(Color.primary_back).cornerRadius(10).fullScreenCover(isPresented: $showChangeSecurity) {
                                            Security(changePinCode: true)
                                        }
                                    }
                                    Toggle(isOn: $chooseTouchID, label: {
                                        Text("Вход по PIN-code")
                                    }).toggleStyle(SwitchToggleStyle(tint: Color.primary_back)).onTapGesture {
                                        self.chooseTouchID.toggle()
                                        UserDefaults.standard.setValue(chooseTouchID, forKey: "PIN-code")
                                    }
                                    
                                    Divider()
                                }
                                
                                
                                HStack{
                                    Text("Помощь")
                                    
                                    Spacer()
                                    
                                    Button(action:{
                                        self.showingHelpForUser.toggle()
                                    }){
                                        Image(systemName: "chevron.right").foregroundColor(.primary_color).font(.title3)
                                    }.padding(.all, 10).background(Color.primary_back).cornerRadius(10).fullScreenCover(isPresented: $showingHelpForUser){
                                        HelpForUser()
                                    }
                                }
                                
                            }.padding(.horizontal, 15).padding(.bottom, 30)
                            
                            Button(action: {
                                self.exitThisApp.toggle()
                            }){
                                RoundedRectangle(cornerRadius: 5).frame(width: 250, height: 50).foregroundColor(Color.primary_back).overlay(
                                    Text("Выход").foregroundColor(.primary_color)
                                )
                            }.padding().fullScreenCover(isPresented: $exitThisApp){
                                SignIn()
                            }
                        }
                    }
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("Настройки").font(.headline)
                    
                }
                
            }.alert(isPresented: $showConfirm) {
                Alert(title: Text("Выйти"), message: Text("Вы уверены что хотите выйти?"),
                      primaryButton: .cancel(Text("Отмена")),
                      secondaryButton: .destructive(Text("Ок")) {
                        DispatchQueue.main.asyncAfter(deadline: .now()) {
                            let domain = Bundle.main.bundleIdentifier!
                            UserDefaults.standard.removePersistentDomain(forName: domain)
                            UserDefaults.standard.synchronize()
                            self.exitThisApp = true
                        }
                      })
            }.alert(isPresented: $showConfirm1) {
                Alert(title: Text("Получать уведомления"), message: Text("Вы уверены что хотите получать уведомления каждый день?"),
                      primaryButton: .cancel(Text("Отмена")),
                      secondaryButton: .destructive(Text("Ок")) {
                        DispatchQueue.main.asyncAfter(deadline: .now()) {
                            UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { success, error in
                                if success {
                                    print("All set!")
                                } else if let error = error {
                                    print(error.localizedDescription)
                                }
                            }
                            let content = UNMutableNotificationContent()
                            content.title = "Уведомление!"
                            content.subtitle = "Не забудьте заполнять транзакции!"
                            content.sound = UNNotificationSound.default

                            // show this notification five seconds from now
                            let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 60, repeats: true)

                            // choose a random identifier
                            let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)

                            // add our notification request
                            UNUserNotificationCenter.current().add(request)
                        }
                      })
            }
        }    .navigationBarColor(backgroundColor: UIColor.primary_color!, tintColor: UIColor.primary_color!)
        
        
    }
}






