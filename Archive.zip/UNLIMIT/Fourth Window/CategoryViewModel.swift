//
//  CategoryViewModel.swift
//  UNLIMIT
//
//  Created by Тимофей on 07.06.2021.
//

import Foundation

class CategoryViewModel: ObservableObject{
    var categories: [Category] = []
    init(){
        if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
            if let user = DatabaseManager.shared.getUser(id: userId){
                self.categories = user.categories.toArray()
            }
        }
    }
}
