//
//  Security.swift
//  UNLIMITApp
//
//  Created by Тимофей on 08.05.2021.
//

import SwiftUI

struct Security: View {
    
    @State var changePinCode = false
    @State var newPinCode = false
    
    @Environment(\.presentationMode) var presentationMode
    
    @State var unLocked = false
    
    var body: some View {
        ZStack{
            ZStack{
                if changePinCode{
                    LockScreen(setting: "1", unLocked: $unLocked)
                }else{
                    if unLocked{
                        HomeView()
                    }
                    else{
                        if newPinCode{
                            LockScreen(setting: "0", unLocked: $unLocked)
                        }else{
                            LockScreen(setting: "3", unLocked: $unLocked)
                        }
                    }
                }
            }
            .preferredColorScheme(.light)
        }.onAppear{
            UIApplication.shared.windows.first?.rootViewController?.view.overrideUserInterfaceStyle = UserDefaults.standard.bool(forKey: "ColorApp") ? .dark : .light
        }
    }
}

struct Security_Previews: PreviewProvider {
    static var previews: some View {
        Security()
    }
}

struct LockScreen : View {
    
    @State var password = ""
    
    @State var setting: String
    
    @State var key: String = UserDefaults.standard.string(forKey: "Pin") ?? ""

    
    @Binding var unLocked : Bool
    
    @State var wrongPassword = false
    
    let height = UIScreen.main.bounds.width
    
    var body: some View{
        
        VStack{
            Image("pincode")
                .resizable()
                .frame(width: 95, height: 95)
                .padding(.top,20)
            switch setting{
            case "0":
                Text("Придумайте Pin-code")
                    .font(.title2)
                    .fontWeight(.heavy)
                    .padding(.top,20)
            case "1":
                Text("Введите старый Pin-code")
                    .font(.title2)
                    .fontWeight(.heavy)
                    .padding(.top,20)
            case "2":
                Text("Введите новый Pin-code")
                    .font(.title2)
                    .fontWeight(.heavy)
                    .padding(.top,20)
            case "3":
                Text("Введите Pin-code")
                    .font(.title2)
                    .fontWeight(.heavy)
                    .padding(.top,20)
            default:
                Text("")
            }
            
            HStack(spacing: 22){
                ForEach(0..<4,id: \.self){index in
                    
                    PasswordView(index: index, password: $password)
                }
            }
            .padding(.top,height < 750 ? 20 : 30)
            
            Spacer(minLength: 0)
            
            Text(wrongPassword ? "Неправильный Pin-code" : "")
                .foregroundColor(.red)
                .fontWeight(.heavy)
            
            Spacer(minLength: 0)
            
            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3),spacing: height < 750 ? 5 : 15){
                
                
                ForEach(1...9,id: \.self){value in
                    
                    PasswordButton(value: "\(value)", setting: $setting, password: $password, key: $key, unlocked: $unLocked, wrongPass: $wrongPassword)
                }
                PasswordButton(value: "delete.fill", setting: $setting,password: $password, key: $key, unlocked: $unLocked, wrongPass: $wrongPassword)
                PasswordButton(value: "0", setting: $setting, password: $password, key: $key, unlocked: $unLocked, wrongPass: $wrongPassword)
                
            }
            .padding(.bottom)
            
        }
        .navigationTitle("")
        .navigationBarHidden(true).onAppear{
            
        }
    }
}

struct PasswordView : View {
    
    var index : Int
    @Binding var password : String
    
    var body: some View{
        
        ZStack{
            
            Circle()
                .stroke(Color.primary_back,lineWidth: 2)
                .frame(width: 30, height: 30)
            
            
            if password.count > index{
                
                Circle()
                    .fill(Color.primary_back)
                    .frame(width: 30, height: 30)
            }
        }
    }
}

struct PasswordButton : View {
    
    @Environment(\.presentationMode) var presentationMode
    
    var value : String
    @Binding var setting: String
    @Binding var password : String
    @Binding var key : String
    @Binding var unlocked : Bool
    @Binding var wrongPass : Bool
    
    var body: some View{
        
        Button(action: setPassword, label: {
            
            VStack{
                
                if value.count > 1{
                    
                    Image(systemName: "delete.left")
                        .font(.system(size: 24))
                        .foregroundColor(.primary_back)
                }
                else{
                    
                    Text(value)
                        .font(.title)
                        .foregroundColor(.primary_back)
                }
            }
            .padding()
            
        })
    }
    
    func setPassword(){
        
        // checking if backspace pressed...
        
        withAnimation{
            
            if value.count > 1{
                
                if password.count != 0{
                    
                    password.removeLast()
                }
            }
            else{
                
                if password.count != 4{
                    
                    password.append(value)
                    
                    // Delay Animation...
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                        
                        withAnimation{
                            
                            if password.count == 4{
                                switch setting {
                                case "0":
                                    UserDefaults.standard.setValue(password, forKey: "Pin")
                                    unlocked = true
                                case "1":
                                    if password == key{
                                        setting = "2"
                                    }
                                    else{
                                        wrongPass = true
                                    }
                                    password.removeAll()
                                case "2":
                                    UserDefaults.standard.setValue(password, forKey: "Pin")
                                    self.presentationMode.wrappedValue.dismiss()
                                case "3":
                                    if password == key{
                                        unlocked = true
                                    }
                                    else{
                                        wrongPass = true
                                        password.removeAll()
                                    }
                                default:
                                    print("wrong")
                                }
                                    
                            }
                        }
                    }
                }
            }
        }
    }
}

