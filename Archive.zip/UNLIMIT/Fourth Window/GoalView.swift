//
//  GoalView.swift
//  UNLIMITApp
//
//  Created by Тимофей on 08.05.2021.
//

import SwiftUI

struct GoalView: View {
    
    @State private var showingAddGoal = false
    @State private var showingDetailedGoal = false
    
    @Environment(\.presentationMode) var presentationMode
    
    @State var goals: [Goal] = []
    
    @State var chooseIndex: Int?
    @State var chooseGoal: Goal?
    
    @State var selection: Int = 0
    private let sortActHis: [String] = ["Актуальные", "Выполнены", "Невыполнены"]
    
    private var trailingBarButtonItems: some View {
        Button(action: {
            withAnimation{
                self.showingAddGoal = true
            }
        }){
            Image(systemName: "plus").font(.title2).foregroundColor(.primary)
        }.fullScreenCover(isPresented: $showingAddGoal) {
            AddGoal(isPresented: $showingAddGoal)
        }
    }
    
    private var leadingBarButtonItems: some View {
        Button(action: {
            withAnimation{
                self.presentationMode.wrappedValue.dismiss()
            }
        }){
            Image(systemName: "arrow.left").font(.title2).foregroundColor(.primary)
        }
    }
    
    var body: some View {
        NavigationView {
            VStack{
                if goals.count == 0{
                    LottieView(animType: .empty_face).frame(width: 300, height: 300).transition( AnyTransition.asymmetric(insertion: .scale, removal: .opacity))
                    VStack {
                        Text("Еще нет целей!").foregroundColor(Color.text_primary_color)
                        Text("Добавьте цель, и она появится здесь").foregroundColor(Color.text_secondary_color).padding(.top, 2)
                    }.padding(.horizontal).transition( AnyTransition.asymmetric(insertion: .scale, removal: .opacity))
                    Spacer()
                }else{
                    ScrollView(.horizontal, showsIndicators: false){
                        SegmentedPicker(items: self.sortActHis, selection: self.$selection)
                    }
                    List{
                        ForEach(Array(zip(goals.indices, goals)), id: \.0){ index, item in
                            switch selection{
                            case 0:
                                if !item.complite && item.endDate >= Date() {
                                    GoalItemView(goal: item).onTapGesture{
                                        self.showingDetailedGoal.toggle()
                                        self.chooseIndex = index
                                        self.chooseGoal = item
                                    }.fullScreenCover(isPresented: $showingDetailedGoal){
                                        DetailedGoalView(isPresented: $showingDetailedGoal, goal: chooseGoal!, index: chooseIndex!)
                                    }
                                    
                                }
                            case 1:
                                if item.complite  {
                                    GoalItemView(goal: item).onTapGesture{
                                        self.showingDetailedGoal.toggle()
                                        self.chooseIndex = index
                                        self.chooseGoal = item
                                    }.fullScreenCover(isPresented: $showingDetailedGoal){
                                        DetailedGoalView(isPresented: $showingDetailedGoal, goal: chooseGoal!, index: chooseIndex!)
                                    }
                                }
                            case 2:
                                if !item.complite && item.endDate < Date() {
                                    GoalItemView(goal: item).onTapGesture{
                                        self.showingDetailedGoal.toggle()
                                        self.chooseIndex = index
                                        self.chooseGoal = item
                                    }.fullScreenCover(isPresented: $showingDetailedGoal){
                                        DetailedGoalView(isPresented: $showingDetailedGoal, goal: chooseGoal!, index: chooseIndex!)
                                    }
                                }
                            default:
                                Text("")
                            }
                        }
                    }
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarItems(leading: leadingBarButtonItems, trailing: trailingBarButtonItems)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("Цель").font(.headline)
                    
                }
                
            }
        }    .navigationBarColor(backgroundColor: UIColor.primary_color!, tintColor: UIColor.primary_color!).dismissKeyboardOnTap()
        .navigationViewStyle(StackNavigationViewStyle()).onAppear{
            getData()
        }.onChange(of: showingAddGoal){_ in
            getData()
        }.onChange(of: showingDetailedGoal) {_ in
            getData()
        }
        
    }
    func getData(){
        if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
            if let user = DatabaseManager.shared.getUser(id: userId){
                self.goals = user.goals.toArray()
            }
        }
    }
}

