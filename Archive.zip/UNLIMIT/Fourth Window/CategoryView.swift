//
//  CategoryView.swift
//  FinanceApp
//
//  Created by Тимофей on 21.05.2021.
//

import SwiftUI
import AlertToast

struct CategoryView: View {
    
    @Environment(\.presentationMode) var presentationMode
    
    @State var showingAddCategory = false
    @State var showingTopToast = false
    @State var showConfirm = false
    
    @State var selection: Int = 0
    private let sortActHis: [String] = ["Расходы", "Доходы"]
    
    @State var chooseType = false
    
    @State var type: String = "-"
    
    @State var text: String = ""
    
    @State var index: Int?
    
    private var trailingBarButtonItems: some View {
        Button(action: {
            withAnimation{
                self.showingAddCategory = true
            }
        }){
            Image(systemName: "plus").font(.title2).foregroundColor(.primary)
        }
    }
    
    @StateObject var viewModel: CategoryViewModel
    
    private var leadingBarButtonItems: some View {
        Button(action: {
            withAnimation{
                self.presentationMode.wrappedValue.dismiss()
            }
        }){
            Image(systemName: "arrow.left").font(.title2).foregroundColor(.primary)
        }
      }
    
    var body: some View {
        
        NavigationView {
            ZStack{
                VStack{
                    SegmentedPicker(items: self.sortActHis, selection: self.$selection)
                
                List{
                    ForEach(Array(zip(viewModel.categories.indices, viewModel.categories)), id: \.0){ index, item in
                        switch selection{
                            case 0:
                                if item.type == "-"{
                                    HStack{
                                        Text("\(item.title)")
                                        Spacer()
                                        if item.system == true{
                                            Image(systemName: "lock").font(.title2).foregroundColor(.primary)
                                        }else{
                                            Button(action:{
                                                self.showConfirm.toggle()
                                                self.index = index
                                            }){
                                                Image(systemName: "xmark.circle").font(.title2).foregroundColor(.primary)
                                            }
                                        }
                                    }
                                }
                            case 1:
                                if item.type == "+"{
                                    HStack{
                                        Text("\(item.title)")
                                        Spacer()
                                        if item.system == true{
                                            Image(systemName: "lock").font(.title2).foregroundColor(.primary)
                                        }else{
                                            Button(action:{
                                                self.showConfirm.toggle()
                                                self.index = index
                                            }){
                                                Image(systemName: "xmark.circle").font(.title2).foregroundColor(.primary)
                                            }
                                        }
                                    }
                                }
                            default:
                                Text("")
                        }
                    }
                }
                }
                AZAlert(title: "Добавить категорию", isShown: $showingAddCategory, text: $text){ text in
                    if selection == 0{
                        self.type = "-"
                    }else{
                        self.type = "+"
                    }
                    let category = Category(id: UUID().uuidString, title: text, type: type, system: false)
                    viewModel.categories.append(category)
                    DatabaseManager.shared.addCategoryToUser(category)
                    self.text = ""
                    self.showingTopToast = true
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarItems(leading: leadingBarButtonItems, trailing: trailingBarButtonItems)
                  .toolbar {
                      ToolbarItem(placement: .principal) {
                              Text("Категории").font(.headline)

                      }
                    
                  }.alert(isPresented: $showConfirm) {
                    Alert(title: Text("Удалить"), message: Text("Вы уверены?"),
                          primaryButton: .cancel(Text("Отмена")),
                          secondaryButton: .destructive(Text("Удалить")) {
                            DispatchQueue.main.asyncAfter(deadline: .now()) {
                                DatabaseManager.shared.deleteCategoryToUser(id: index!)
                                viewModel.categories.remove(at: index!)
                            }
                          })
                }
        }    .navigationBarColor(backgroundColor: .primary_color!, tintColor: .primary_color!).dismissKeyboardOnTap()
        .navigationViewStyle(StackNavigationViewStyle()).toast(isPresenting: $showingTopToast, duration: 2, tapToDismiss: false){
            AlertToast(type: .regular, title: "Категория успешно создана!")
        }
        
    }
}

struct CategoryView_Previews: PreviewProvider {
    static var previews: some View {
        CategoryView(viewModel: CategoryViewModel())
    }
}
