//
//  GoalItemView.swift
//  UNLIMIT
//
//  Created by Тимофей on 11.06.2021.
//

import SwiftUI

struct GoalItemView: View {
    
    var goal: Goal
    
    var body: some View {
        HStack{
            VStack{
                Text("\(goal.title)").font(.headline)
                if !goal.complite && goal.endDate >= Date(){
                    Text("Активное").font(.headline)
                }else if goal.complite{
                    Text("Выполнено")
                }else{
                    Text("Не выполнено")
                }
            }
            Spacer()
            VStack{
                Text("\(goal.amount, specifier: "%.2f")").font(.headline)
                Text("К \(goal.endDate.toString())").font(.headline)
            }
        }.padding(.horizontal, 10)
    }
}

