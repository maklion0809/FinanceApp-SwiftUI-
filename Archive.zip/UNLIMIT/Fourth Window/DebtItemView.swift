//
//  DebtItemView.swift
//  UNLIMIT
//
//  Created by Тимофей on 11.06.2021.
//

import SwiftUI

struct DebtItemView: View {
    
    var debt: Debt
    
    var body: some View {
        VStack{
            HStack{
                VStack{
                    Text("Cрок - \(debt.endDate.toString())")
                    Text("\(debt.type) - \(debt.title)").font(.headline)
                }
                Spacer()
                Text("\(debt.amount, specifier: "%.2f")").font(.headline)
            }
        }.padding(.horizontal, 10)
    }
}
