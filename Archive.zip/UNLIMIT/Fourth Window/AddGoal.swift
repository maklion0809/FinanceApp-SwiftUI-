//
//  CreateAim.swift
//  UNLIMITApp
//
//  Created by Тимофей on 07.05.2021.
//

import SwiftUI
import ConfettiSwiftUI

struct AddGoal: View {
        
    @Binding var isPresented: Bool
    
    @State var title = ""
    @State var amount = ""
    @State var note = ""
    @State var chooseComoleted = false
    @State var endDate = Date()
    
    @State var message = ""
    @State var alert = false
    @State var show = false
    
    private var leadingBarButtonItems: some View {
        Button(action: {
            isPresented = false
        }){
            Image(systemName: "arrow.left").font(.title2).foregroundColor(.primary)
        }
      }
    
    var body: some View {
        
        NavigationView {
            ZStack{
                Color.primary_color.edgesIgnoringSafeArea(.all)
                VStack{
                    ScrollView(showsIndicators: false){
                        
                        VStack(spacing: 12){
                            
                            Image("golf").resizable().aspectRatio(contentMode: .fit).frame(width: 200, height: 200, alignment: .center)
                          
                            TextField("Название", text: $title)
                                .accentColor(Color.text_primary_color)
                                .frame(height: 50).padding(.leading, 16)
                                .background(Color.secondary_color)
                                .cornerRadius(4)
                            HStack{
                                TextField("Сумма", text: $amount).keyboardType(.decimalPad)
                                Spacer()
                                VStack{
                                    Text("В месяц").font(.caption2)
                                    Text(amount == "" ? "-" : ( getInMonth() == nil ? "error" : "\(getInMonth()!, specifier: "%.2f")"))
                                }.padding(.trailing, 15)

                            }.accentColor(Color.text_primary_color)
                            .frame(height: 50).padding(.leading, 16)
                            .background(Color.secondary_color)
                            .cornerRadius(4)
                            
                            
                            HStack{
                                
                                DatePicker("PickerView", selection: $endDate, displayedComponents: [.date]).labelsHidden().padding(.leading, 16).accentColor(Color.text_primary_color)
                                Spacer()
                                VStack{
                                    Text("Месяцев").font(.caption2)
                                    Text(amount == "" ? "-" : "\(getMonthes(), specifier: "%.2f")")
                                }.padding(.trailing, 15)
                            }.accentColor(Color.text_primary_color)
                            .frame(height: 50).padding(.leading, 16)
                            .background(Color.secondary_color)
                            .cornerRadius(4)
                            
                            TextField("Заметка", text: $note)
                                .accentColor(Color.text_primary_color)
                                .frame(height: 50).padding(.leading, 16)
                                .background(Color.secondary_color)
                                .cornerRadius(4)
                            
                            HStack{
                                Toggle(isOn: $chooseComoleted, label: {
                                    Image(systemName: "checkmark.circle").resizable().frame(width: 25, height: 25)
                                    Text("Выполнено").accentColor(Color.text_primary_color)
                                }).toggleStyle(SwitchToggleStyle(tint: Color.primary_back)).padding(.trailing, 30)
                                
                            }.accentColor(Color.text_primary_color)
                            .frame(height: 50).padding(.leading, 16)
                            .background(Color.secondary_color)
                            .cornerRadius(4)
                            
                            
                                                        
                        }
                        Button(action: {
                            if let actualSumGoal = Double(self.amount), let actulaGetMonthes = getInMonth(){
                                let goal = Goal(id: UUID().uuidString, title: title, amount: actualSumGoal, inMonth: getMonthes(), complite: chooseComoleted, endDate: endDate, monthes: actulaGetMonthes, note: note)
                                DatabaseManager.shared.addGoalToUser(goal)
                                isPresented = false
                            }else{
                                self.message = "Некоректное значение"
                                self.alert.toggle()
                            }
                        }) {
                        
                            RoundedRectangle(cornerRadius: 5).frame(width: 250, height: 50).foregroundColor(Color.primary_back).overlay(
                                Text("Добавить цель").foregroundColor(.primary_color)
                            )
                        }.padding()
                    }
                }
            }
            .alert(isPresented: $alert) {
                Alert(title: Text("Ошибка"), message: Text(self.message), dismissButton: .default(Text("Ok")))
            }
            .navigationBarTitleDisplayMode(.inline)
                  .navigationBarItems(leading: leadingBarButtonItems)
                  .toolbar {
                      ToolbarItem(placement: .principal) {
                              Text("Добавить цель").font(.headline)

                      }
                    
                  }
        }    .navigationBarColor(backgroundColor: UIColor.primary_color!, tintColor: UIColor.primary_color!).dismissKeyboardOnTap()
        .navigationViewStyle(StackNavigationViewStyle())
    }
    
    func getInMonth() -> Double?{
        if let actualAmount = Double(amount){
            return Double(actualAmount/Double(getMonthes()))
        }
        return nil
    }
    
    func getMonthes() -> Double{
        let sumMonthes = Double(Calendar.current.dateComponents([.month], from: Date(), to: endDate).month!) + Double(Double(endDate.startOfMonth().days(to: endDate) + 1 - (Date().startOfMonth().days(to: Date()) + 1))/30)
        if sumMonthes >= 1{
            return sumMonthes
        }else{
            return 1
        }
        
    }
}
