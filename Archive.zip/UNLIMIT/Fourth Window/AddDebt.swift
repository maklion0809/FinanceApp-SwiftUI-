//
//  CreateDebt.swift
//  UNLIMITApp
//
//  Created by Тимофей on 04.05.2021.
//

import SwiftUI

struct AddDebt: View {
    
    @Binding var isPresented: Bool

    @State var amount = ""
    @State var note = ""
    @State var title = ""
    @State var type = "Кому должен я"
    @State var types: [String] = ["Кому должен я", "Кто должен мне"]
    @State var startDate = Date()
    @State var endDate = Date()
    @State var message = ""
    @State var alert = false
    @State var show = false
    @State var selectedDebtIndex = false
    @State var chooseComoleted = false
    
    let user = DatabaseManager.shared.getUser(id: UserDefaults.standard.string(forKey: "ChooseUser")!)

    private var leadingBarButtonItems: some View {
        Button(action: {
            isPresented = false
        }){
            Image(systemName: "arrow.left").font(.title2).foregroundColor(.primary)
        }
      }
    
    
    
    var body: some View {
        
        return NavigationView {
            ZStack{
                Color.primary_color.edgesIgnoringSafeArea(.all)
                VStack{
                    ScrollView(showsIndicators: false){
                        
                        VStack(spacing: 12){
                            
                            Image("debt").resizable().aspectRatio(contentMode: .fit).frame(width: 200, height: 200, alignment: .center)
                            
                            DisclosureGroup("\(type)", isExpanded: $selectedDebtIndex){
                                VStack{
                                    ForEach(types, id: \.self){ num in
                                        HStack{
                                            Text("\(num)")
                                            Spacer()
                                        }.onTapGesture {
                                            self.type = String(num)
                                            withAnimation{
                                                self.selectedDebtIndex.toggle()
                                            }
                                        }
                                    }.accentColor(Color.text_primary_color).frame(height: 50)
                                }
                            }.accentColor(Color.text_primary_color).padding(.vertical, 10).padding(.horizontal, 16).background(Color.secondary_color).cornerRadius(4).keyboardType(.decimalPad)
                            
                            TextField("Сумма", text: $amount)
                                .accentColor(Color.text_primary_color)
                                .frame(height: 50).padding(.leading, 16)
                                .background(Color.secondary_color)
                                .cornerRadius(4).keyboardType(.decimalPad)
                            
                            TextField("\(type)", text: $title)
                                .accentColor(Color.text_primary_color)
                                .frame(height: 50).padding(.leading, 16)
                                .background(Color.secondary_color)
                                .cornerRadius(4)
                            
                            
                            HStack {
                                DatePicker("PickerView", selection: $startDate,
                                           displayedComponents: [.date]).labelsHidden().padding(.leading, 16).accentColor(Color.text_primary_color)
                                Spacer()
                                
                                Image(systemName: "arrow.right").font(.title2).foregroundColor(.primary)
                                
                                Spacer()
                                
                                DatePicker("PickerView", selection: $endDate,
                                           displayedComponents: [.date]).labelsHidden().padding(.trailing, 16).accentColor(Color.text_primary_color)
                            }
                            .frame(height: 50).frame(maxWidth: .infinity)
                            .background(Color.secondary_color).cornerRadius(4)
                            
                            HStack{
                                Toggle(isOn: $chooseComoleted, label: {
                                    Image(systemName: "checkmark.circle").resizable().frame(width: 25, height: 25)
                                    Text("Выполнено").accentColor(Color.text_primary_color)
                                }).toggleStyle(SwitchToggleStyle(tint: Color.primary_back)).padding(.trailing, 30)
                                
                            }.accentColor(Color.text_primary_color)
                            .frame(height: 50).padding(.leading, 16)
                            .background(Color.secondary_color)
                            .cornerRadius(4)
                            
                            TextField("Заметка", text: $note)
                                .accentColor(Color.text_primary_color)
                                .frame(height: 50).padding(.leading, 16)
                                .background(Color.secondary_color)
                                .cornerRadius(4)
                            
                            
                                                        
                        }
                        Button(action: {
                            if let actualSumDebt = Double(self.amount){
                                let debt = Debt(id: UUID().uuidString, title: title, amount: actualSumDebt, type: type, startDate: startDate, endDate: endDate, note: note, complite: chooseComoleted)
                                DatabaseManager.shared.addDebtToUser(debt)
                                isPresented = false
                            }else{
                                self.message = "Некоректное значение"
                                self.alert.toggle()
                            }
                        }) {
                        
                            RoundedRectangle(cornerRadius: 5).frame(width: 250, height: 50).foregroundColor(Color.primary_back).overlay(
                                Text("Добавить долг").foregroundColor(.primary_color)
                            )
                        }.padding()
                    }
                }
            }
            .alert(isPresented: $alert) {
                Alert(title: Text("Error"), message: Text(self.message), dismissButton: .default(Text("Ok")))
            }
            .navigationBarTitleDisplayMode(.inline)
                  .navigationBarItems(leading: leadingBarButtonItems)
                  .toolbar {
                      ToolbarItem(placement: .principal) {
                              Text("Добавить долг").font(.headline)

                      }
                    
                  }
        }    .navigationBarColor(backgroundColor: UIColor.primary_color!, tintColor: UIColor.primary_color!).dismissKeyboardOnTap()
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

