//
//  DetailedGoalView.swift
//  UNLIMIT
//
//  Created by Тимофей on 09.06.2021.
//

import SwiftUI

struct DetailedGoalView: View {
    
    @State var chooseComoleted = false
    
    @State var showUpdateGoal = false
    
    @Binding var isPresented: Bool
    
    @State var showConfirm = false
    
    var goal: Goal
    
    var index: Int
    
    private var leadingBarButtonItems: some View {
        Button(action: {
            if chooseComoleted{
                DatabaseManager.shared.updateGoalToUser(id: index, complite: true)
            }
            isPresented = false
        }){
            Image(systemName: "arrow.left").font(.title2).foregroundColor(.primary)
        }
      }
    private var traillingBarButtonItems: some View {
        Button(action: {
            self.showConfirm.toggle()
        }){
            Image(systemName: "trash").font(.title2).foregroundColor(.primary)
        }
      }
    var body: some View {
        NavigationView {
            ZStack{
                Color.primary_color.edgesIgnoringSafeArea(.all)
                VStack{
                    ScrollView(showsIndicators: false){
                        
                        VStack(spacing: 12){
                            Image("goal1").resizable().aspectRatio(contentMode: .fit).frame(width: 200, height: 200, alignment: .center)
                            
                            Text("Название - \(goal.title)")
                                .accentColor(Color.text_primary_color)
                                .frame(height: 50).padding(.leading, 16)
                            Text("Cумма - \(goal.amount, specifier: "%.2f")")
                                .accentColor(Color.text_primary_color)
                                .frame(height: 50).padding(.leading, 16)
                            
                            Text("В месяц - \(goal.inMonth, specifier: "%.2f")")
                                .accentColor(Color.text_primary_color)
                                .frame(height: 50).padding(.leading, 16)
                            
                            Text("Дaтa - \(goal.endDate.toString())")
                                .accentColor(Color.text_primary_color)
                                .frame(height: 50).padding(.leading, 16)
                            
                            Text("Месяцев - \(goal.monthes, specifier: "%.2f")")
                                .accentColor(Color.text_primary_color)
                                .frame(height: 50).padding(.leading, 16)
                            if goal.complite{
                                Text("Статус - цель достигнута")
                                    .accentColor(Color.text_primary_color)
                                    .frame(height: 50).padding(.leading, 16)
                            }else{
                                    Toggle(isOn: $chooseComoleted, label: {
                                        if goal.endDate >= Date(){
                                            Text("Статус - цель активна").accentColor(Color.text_primary_color).padding(.leading, 30)
                                        }else{
                                            Text("Cтатус - цель не выполнена").accentColor(Color.text_primary_color).padding(.leading, 30)
                                        }
                                    }).toggleStyle(SwitchToggleStyle(tint: Color.primary_back)).padding(.trailing, 30)
                            }
                            if let note = goal.note, note != ""{
                                Text("Зaметкa: \(note)")
                                    .accentColor(Color.text_primary_color)
                                    .frame(height: 50).padding(.leading, 16)
                            }
                        }
                    }
                }
            }
            .navigationBarTitleDisplayMode(.inline)
                  .navigationBarItems(leading: leadingBarButtonItems, trailing: traillingBarButtonItems)
                  .toolbar {
                      ToolbarItem(placement: .principal) {
                              Text("Детали долга").font(.headline)

                      }
                    
                  }.alert(isPresented: $showConfirm) {
                    Alert(title: Text("Удалить"), message: Text("Вы уверены?"),
                          primaryButton: .cancel(Text("Отмена")),
                          secondaryButton: .destructive(Text("Удалить")) {
                            DispatchQueue.main.asyncAfter(deadline: .now()) {
                                DatabaseManager.shared.deleteGoalToUser(id: index)
                                isPresented = false
                            }
                          })
                }
        }    .navigationBarColor(backgroundColor: .primary_color!, tintColor: .primary_color!).dismissKeyboardOnTap()
        .navigationViewStyle(StackNavigationViewStyle())
    }
}
