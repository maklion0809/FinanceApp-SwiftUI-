//
//  HelpForUser.swift
//  UNLIMIT
//
//  Created by Тимофей on 08.06.2021.
//

import SwiftUI

struct HelpForUser: View {
    
    @Environment(\.presentationMode) var presentationMode
    
    private var leadingBarButtonItems: some View {
        Button(action: {
            self.presentationMode.wrappedValue.dismiss()
        }){
            Image(systemName: "arrow.left").font(.title2).foregroundColor(.primary)
        }
      }
    var body: some View {
        NavigationView {
            ZStack{
                Color.primary_color.edgesIgnoringSafeArea(.all)
                VStack{
                    ScrollView(showsIndicators: false){
                        
                            VStack(alignment: .leading, spacing: 10) {
                                HStack{
                                    Image("telegram-1").resizable().frame(width: 50, height: 50)
                                    Text(" Telegram")
                                    Spacer()
                                }.foregroundColor(Color.main_color).padding(.top, 2)
                                    .onTapGesture {
                                        if let url: URL = URL(string: "https://github.com/maklion0809") {
                                            UIApplication.shared.open(url)
                                        }
                                    }
                                HStack{
                                    Image("github").resizable().frame(width: 50, height: 50)
                                    Text(" GitHub")
                                    Spacer()

                                }.foregroundColor(Color.main_color).padding(.top, 2)
                                    .onTapGesture {
                                        if let url: URL = URL(string: "https://github.com/maklion0809") {
                                            UIApplication.shared.open(url)
                                        }
                                    }
                            }.padding(.all, 20)
                            
                    }
                }
            }.navigationBarTitleDisplayMode(.inline)
                  .navigationBarItems(leading: leadingBarButtonItems)
                  .toolbar {
                      ToolbarItem(placement: .principal) {
                              Text("Помощь").font(.headline)
                      }
                    
                  }
        }    .navigationBarColor(backgroundColor: UIColor.primary_color!, tintColor: UIColor.primary_color!).dismissKeyboardOnTap()
        .navigationViewStyle(StackNavigationViewStyle())
            
    }
}

struct HelpForUser_Previews: PreviewProvider {
    static var previews: some View {
        HelpForUser()
    }
}
