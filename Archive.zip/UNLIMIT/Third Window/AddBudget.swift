//
//  CreateBudget.swift
//  UNLIMITApp
//
//  Created by Тимофей on 04.05.2021.
//

import SwiftUI

struct AddBudget: View {
    
    @Binding var isPresented: Bool

    @State var categories: [Category] = []
                
    @State var title = ""
    @State var amount: String = ""
    @State var categoryText: [Category] = []
    @State var startDate = Date()
    @State var endDate = Date()
    @State var message = ""
    @State var alert = false
    @State var show = false
    
    @State var selectedCategoryIndex = false
    
    @State var selectedAllCategory = false

    private var leadingBarButtonItems: some View {
        Button(action: {
            withAnimation{
                isPresented = false
            }
        }){
            Image(systemName: "arrow.left").font(.title2).foregroundColor(.primary)
        }
      }
    
    var body: some View {
        
        NavigationView {
            ZStack{
                Color.primary_color.edgesIgnoringSafeArea(.all)
                VStack{
                    ScrollView(showsIndicators: false){
                        
                        VStack(spacing: 12){
                            
                            Image("budget").resizable().aspectRatio(contentMode: .fit).frame(width: 200, height: 200, alignment: .center)
                            
                            TextField("Название", text: $title)
                                .accentColor(Color.text_primary_color)
                                .frame(height: 50).padding(.leading, 16)
                                .background(Color.secondary_color)
                                .cornerRadius(4)
                            
                            TextField("Сумма", text: $amount)
                                .accentColor(Color.text_primary_color)
                                .frame(height: 50).padding(.leading, 16)
                                .background(Color.secondary_color)
                                .cornerRadius(4).keyboardType(.decimalPad)
                            
                            DisclosureGroup("\(getCategoryTitle())", isExpanded: $selectedCategoryIndex){
                                VStack{
                                    HStack{
                                        Text(selectedAllCategory ? "Отменить все" : "Выбрать все").onTapGesture {
                                            self.selectedAllCategory.toggle()
                                            if selectedAllCategory{
                                                self.categoryText = categories
                                            }else{
                                                self.categoryText = [categories[0]]
                                            }
                                            withAnimation{
                                                self.selectedCategoryIndex.toggle()
                                            }
                                        }.padding()
                                        Spacer()
                                    }
                                    ForEach(categories){ category in
                                        HStack{
                                            Text("\(category.title)").onTapGesture {
                                                if !categoryText.contains(category){
                                                    self.categoryText.append(category)
                                                    withAnimation{
                                                        self.selectedCategoryIndex.toggle()
                                                    }
                                                }else{
                                                    if let index = categoryText.firstIndex(of: category){
                                                        categoryText.remove(at: index)
                                                        withAnimation{
                                                            self.selectedCategoryIndex.toggle()
                                                        }
                                                    }
                                                }
                                            }
                                            Spacer()
                                            if categoryText.contains(category){
                                                Image(systemName: "checkmark").resizable().frame(width: 15, height: 15).foregroundColor(.primary_back)
                                            }
                                        }
                                    }.accentColor(Color.text_primary_color).frame(height: 50)
                                }
                            }.accentColor(Color.text_primary_color).padding(.vertical, 10).padding(.horizontal, 16).background(Color.secondary_color).cornerRadius(4).keyboardType(.decimalPad)
                            
                            HStack {
                                DatePicker("PickerView", selection: $startDate,
                                           displayedComponents: [.date]).labelsHidden().padding(.leading, 16).accentColor(Color.text_primary_color)
                                Spacer()
                                
                                Image(systemName: "arrow.right").font(.title2).foregroundColor(.primary)
                                
                                Spacer()
                                
                                DatePicker("PickerView", selection: $endDate,
                                           displayedComponents: [.date]).labelsHidden().padding(.trailing, 16).accentColor(Color.text_primary_color)
                            }
                            .frame(height: 50).frame(maxWidth: .infinity)
                            .background(Color.secondary_color).cornerRadius(4)
                            
                            
                        }
                        Button(action: {
                            if let actualAmount = Double(self.amount){
                                if categoryText.count != 0{
                                    let budget = Budget(id: UUID().uuidString, title: title, amount: actualAmount, startDate: startDate, endDate: endDate, categories: categoryText)
                                    DatabaseManager.shared.addBudgetToWallet(budget)
                                    isPresented = false
                                }else{
                                    self.message = "Отсутствует категория"
                                    self.alert.toggle()
                                }
                            }else{
                                self.message = "Некоректное значение"
                                self.alert.toggle()
                            }
                        
                        }) {
                        
                            RoundedRectangle(cornerRadius: 5).frame(width: 250, height: 50).foregroundColor(Color.primary_back).overlay(
                                Text("Создать бюджет").foregroundColor(.primary_color)
                            )
                        }.padding()
                    }
                }
            }
            .alert(isPresented: $alert) {
                Alert(title: Text("Error"), message: Text(self.message), dismissButton: .default(Text("Ok")))
            }
            .navigationBarTitleDisplayMode(.inline)
                  .navigationBarItems(leading: leadingBarButtonItems)
                  .toolbar {
                      ToolbarItem(placement: .principal) {
                              Text("Добавить бюджет").font(.headline)

                      }
                    
                  }
        }    .navigationBarColor(backgroundColor: UIColor.primary_color!, tintColor: UIColor.primary_color!).dismissKeyboardOnTap()
        .navigationViewStyle(StackNavigationViewStyle()).onAppear{
            if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
                if let user = DatabaseManager.shared.getUser(id: userId){
                    let category = user.categories.toArray()
                    for item in category{
                        if item.type == "-"{
                            self.categories.append(item)
                        }
                    }
                    self.categoryText.append(self.categories[0])
                }
            }
        }
                
    }
    func getCategoryTitle() -> String{
        var str = ""
        for item in categoryText{
            str += item.title + ", "
        }
        return String(str.dropLast(2))
    }
}

