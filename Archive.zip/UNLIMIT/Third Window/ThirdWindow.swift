//
//  ThirdWindow.swift
//  UNLIMITApp
//
//  Created by Тимофей on 27.04.2021.
//

import SwiftUI

struct ThirdWindow: View {
    
    @State private var showingAddBudget = false
    @State private var showingSettingBudget = false
    
    @State var chooseIndex: Int?
    @State var chooseBudget: Budget?
    
    private var trailingBarButtonItems: some View {
        Button(action: {
            self.showingAddBudget = true
        }){
            Image(systemName: "plus").font(.title2).foregroundColor(.primary)
        }.fullScreenCover(isPresented: $showingAddBudget){
            AddBudget(isPresented: $showingAddBudget)
        }
    }
    
    @State var selection: Int = 0
    private let sortActHis: [String] = ["Актуальные", "История"]
    
    @State var budgets: [Budget] = []
    
    var body: some View {
        NavigationView {
            VStack{
                if budgets.count == 0{
                    LottieView(animType: .empty_face).frame(width: 300, height: 300).transition( AnyTransition.asymmetric(insertion: .scale, removal: .opacity))
                    VStack {
                        Text("Еще нет бюджетов!").foregroundColor(Color.text_primary_color)
                        Text("Добавьте бюджет, и он появится здесь").foregroundColor(Color.text_secondary_color).padding(.top, 2)
                    }.padding(.horizontal).transition( AnyTransition.asymmetric(insertion: .scale, removal: .opacity))
                    Spacer()
                }else{
                    SegmentedPicker(items: self.sortActHis, selection: self.$selection)
                    List{
                        ForEach(Array(zip(budgets.indices, budgets)), id: \.0){ index, item in
                            switch selection{
                            case 0:
                                if item.endDate > Date(){
                                    BudgetView(budget: item).onTapGesture{
                                        self.showingSettingBudget.toggle()
                                        self.chooseIndex = index
                                        self.chooseBudget = item
                                    }.fullScreenCover(isPresented: $showingSettingBudget){
                                        DetailedBudgetView(isPresented: $showingSettingBudget, budget: chooseBudget!, index: chooseIndex!)
                                    }
                                }
                            case 1:
                                if item.endDate < Date(){
                                    BudgetView(budget: item).onTapGesture{
                                        self.showingSettingBudget.toggle()
                                        self.chooseIndex = index
                                        self.chooseBudget = item
                                    }.fullScreenCover(isPresented: $showingSettingBudget){
                                        DetailedBudgetView(isPresented: $showingSettingBudget, budget: chooseBudget!, index: chooseIndex!)
                                    }
                                }
                            default:
                                Text("")
                            }
                            
                        }
                    }
                }
            }.navigationBarTitleDisplayMode(.inline).animation(.spring())
            .navigationBarItems(trailing: trailingBarButtonItems)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("Бюджеты").font(.headline)
                    
                }
                
            }
        }.navigationBarColor(backgroundColor: UIColor.primary_color!, tintColor: UIColor.primary_color!).dismissKeyboardOnTap()
        .navigationViewStyle(StackNavigationViewStyle()).onAppear{
            getData()
        }.onChange(of: showingAddBudget){_ in
            getData()
        }.onChange(of: showingSettingBudget){_ in
            getData()
        }
    }
    
    func getData(){
        if let indexUser = UserDefaults.standard.string(forKey: "ChooseUser"){
            if let user = DatabaseManager.shared.getUser(id: indexUser){
                if let indexWallet = UserDefaults.standard.object(forKey: "ChooseWallet"){
                    self.budgets = user.wallets[indexWallet as! Int].budgets.toArray()
                }
            }
        }
    }
}

