//
//  SettingBudget.swift
//  UNLIMITApp
//
//  Created by Тимофей on 29.04.2021.
//

import SwiftUI

struct DetailedBudgetView: View {
    
    @Binding var isPresented: Bool
    
    @State var showUpdateBudget = false
    
    var budget: Budget
    
    @State var transactions: [Transaction] = []
    
    var index: Int
    
    @State var showConfirm = false
    
    private var leadingBarButtonItems: some View {
        Button(action: {
            isPresented = false
        }){
            Image(systemName: "arrow.left").font(.title2).foregroundColor(.primary)
        }
    }
    private var traillingBarButtonItems: some View {
        Button(action: {
            self.showConfirm.toggle()
        }){
            Image(systemName: "trash").font(.title2).foregroundColor(.primary)
        }
    }
    
    
    
    @State var progress: CGFloat = 0.0
    
    
    var body: some View {
        
        NavigationView {
            ZStack{
                Color.primary_color.edgesIgnoringSafeArea(.all)
                VStack{
                    Spacer(minLength: 12)
                    ZStack{
                        Circle().trim(from: 0, to: 1/1.5).stroke(Color.primary_back.opacity(0.05), lineWidth: 10).frame(width: (UIScreen.main.bounds.width - 100), height: (UIScreen.main.bounds.width - 100)).rotationEffect(Angle(degrees: -210))
                        Circle().trim(from: 0, to: CGFloat((getCurBalanceForBudget() / budget.amount)/1.5)).stroke(Color.primary_back, style: StrokeStyle(lineWidth: 10, lineCap: .round)).frame(width: (UIScreen.main.bounds.width - 100), height: (UIScreen.main.bounds.width - 100)).rotationEffect(Angle(degrees: -210))
                        VStack{
                            Text("\(getCurBalanceForBudget(), specifier: "%.2f")").font(.system(size: 30)).fontWeight(.bold)
                            Text("Расходов").font(.system(size: 20)).foregroundColor(.gray)
                        }
                    }
                        HStack{
                            VStack{
                                Text("\(getCurBalanceForBudget(), specifier: "%.2f")").font(.system(size: 30)).fontWeight(.bold)
                                Text("Текущая сумма").font(.system(size: 15)).foregroundColor(.gray)
                            }
                            Spacer()
                            VStack{
                                Text("\(budget.amount, specifier: "%.2f")").font(.system(size: 30)).fontWeight(.bold)
                                Text("Лимит за период").font(.system(size: 15)).foregroundColor(.gray)
                            }
                        }.padding(.horizontal, 20).padding(.bottom, 30)
                    
                    
                    Text("Категории - \(getCategoryTitle())").fontWeight(.bold).accentColor(Color.text_primary_color).padding(.horizontal, 10)
                    
                    List{
                        ForEach(transactions){ item in
                            TransactionView(transactions: item)
                        }
                    }
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarItems(leading: leadingBarButtonItems, trailing: traillingBarButtonItems)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("\(budget.title)").font(.headline)
                    
                }
                
            }.alert(isPresented: $showConfirm) {
                Alert(title: Text("Удалить"), message: Text("Вы уверены?"),
                      primaryButton: .cancel(Text("Отмена")),
                      secondaryButton: .destructive(Text("Удалить")) {
                        DispatchQueue.main.asyncAfter(deadline: .now()) {
                            DatabaseManager.shared.deleteBudgetToWallet(id: index)
                            isPresented = false
                        }
                      })
            }
        }    .navigationBarColor(backgroundColor: .primary_color!, tintColor: .primary_color!).dismissKeyboardOnTap()
        .navigationViewStyle(StackNavigationViewStyle()).onAppear{
            if let indexUser = UserDefaults.standard.string(forKey: "ChooseUser"){
                if let user = DatabaseManager.shared.getUser(id: indexUser){
                    if let indexWallet = UserDefaults.standard.object(forKey: "ChooseWallet"){
                        let transactionBudget = user.wallets[indexWallet as! Int].transactions.toArray()
                        for item in transactionBudget{
                            if budget.categories.contains(item.category!){
                                transactions.append(item)
                            }
                        }
                    }
                }
            }
        }
    }
    func getCurBalanceForBudget() -> Double{
        var sum = 0.0
        for item in transactions{
            sum += item.amount
        }
        return sum
    }
    func getCategoryTitle() -> String{
        var str = ""
        for item in budget.categories{
            str += item.title + ", "
        }
        return String(str.dropLast(2))
    }
}

