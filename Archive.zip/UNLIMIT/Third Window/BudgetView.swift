//
//  BudgetView.swift
//  UNLIMITApp
//
//  Created by Тимофей on 07.05.2021.
//

import SwiftUI

struct BudgetView: View {
    
    @State var transactions: [Transaction] = []
    
    @State var percent: CGFloat = 0
    
    var budget: Budget
    
    var body: some View {
            
                VStack{
                    HStack{
                        Text("\(budget.title)").bold().font(.title2).foregroundColor(.primary_back)
                        Spacer()
                        if budget.endDate < Date(){
                            Text("Неактивный").bold().font(.title2).foregroundColor(.primary_back)
                        }else{
                            Text("Активный").bold().font(.title2).foregroundColor(.primary_back)
                        }
                    }
                    HStack{
                        Text("\(budget.startDate.toString())").foregroundColor(.gray).font(.title3)
                        Spacer()
                        Text("-").foregroundColor(.gray).font(.title3)
                        Spacer()
                        Text("\(budget.endDate.toString())").foregroundColor(.gray).font(.title3)
                    }
                    
                    ZStack(alignment: .leading){
                        
                        
                        Capsule().fill(Color.primary_back.opacity(0.08)).frame(height: 30)
                    
                        Capsule().fill(LinearGradient(gradient: .init(colors:  self.getColor()), startPoint: .leading, endPoint: .trailing)).frame(width: self.calPercent(),height: 30)
                        HStack{
                            Text("\(getCurBalanceForBudget(), specifier: "%.2f")").bold().font(.title2).foregroundColor(.primary_back)
                            Spacer()
                            Text("\(budget.amount, specifier: "%.2f")").bold().font(.title2).foregroundColor(.primary_back)
                        }
                    }
                        
                    
                }.padding().onAppear{
                    if let indexUser = UserDefaults.standard.string(forKey: "ChooseUser"){
                        if let user = DatabaseManager.shared.getUser(id: indexUser){
                            if let indexWallet = UserDefaults.standard.object(forKey: "ChooseWallet"){
                                let transactionBudget = user.wallets[indexWallet as! Int].transactions.toArray()
                                for item in transactionBudget{
                                    if budget.categories.contains(item.category!){
                                        transactions.append(item)
                                    }
                                }
                            }
                        }
                    }
                }
    }
    func getCurBalanceForBudget() -> Double{
        var sum = 0.0
        for item in transactions{
            sum += item.amount
        }
        return sum
    }

    func getColor() -> [Color]{
        let result = getCurBalanceForBudget() / self.budget.amount
        if result <= 0.5{
            return [.yellow]
        }else if result <= 0.9{
            return [.yellow, .orange]
        }else{
            return [.yellow,.orange,.red]
        }
    }
    
    func calPercent() -> CGFloat{
        let width = UIScreen.main.bounds.width - 50
        
        if getCurBalanceForBudget() < self.budget.amount{
            return width * CGFloat(getCurBalanceForBudget() / self.budget.amount)
        }else{
            return width
        }
    }
}
