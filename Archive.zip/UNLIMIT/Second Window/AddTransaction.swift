//
//  CreateTransaction.swift
//  UNLIMITApp
//
//  Created by Тимофей on 04.05.2021.
//

import SwiftUI


struct AddTransaction: View {
    
    @Binding var isPresented: Bool
    
    @State var categories: [Category] = []
    
    @State var occuredOnDatePicker = Date()
    
    @State var note = ""
    @State var amount = ""
    @State var message = ""
    @State var categoryText: Category?
    
    @State var typeText = ["Расходы", "-"]
    
    @State var index: Int?
    
    @State var alert = false
    @State var show = false
    @State var selectedCategoryIndex = false
    @State var selectedIncExpIndex = false
    
    private var leadingBarButtonItems: some View {
        Button(action: {
            isPresented = false
        }){
            Image(systemName: "arrow.left").font(.title2).foregroundColor(.primary)
        }
    }
    
    let types: [[String]] = [["Расходы", "-"], ["Доходы", "+"]]
    
    var body: some View {
        NavigationView {
            ZStack{
                Color.primary_color.edgesIgnoringSafeArea(.all)
                VStack{
                    ScrollView(showsIndicators: false){
                        
                        VStack(spacing: 12){
                            Group{
                                Image("transaction").resizable().aspectRatio(contentMode: .fit).frame(width: 300, height: 300, alignment: .center)
                                
                                TextField("Сумма", text: $amount).accentColor(Color.text_primary_color).frame(height: 50).padding(.leading, 16).background(Color.secondary_color).cornerRadius(4).keyboardType(.decimalPad)
                            }
                            
                            DisclosureGroup("\(typeText[0])", isExpanded: $selectedIncExpIndex){
                                VStack{
                                    ForEach(types, id: \.self){ type in
                                        HStack{
                                            Text("\(type[0])").onTapGesture {
                                                self.typeText = type
                                                for item in categories{
                                                    if item.type == "-" && typeText[1] == "-"{
                                                        self.categoryText = item
                                                        break
                                                    }else if item.type == "+" && typeText[1] == "+"{
                                                        self.categoryText = item
                                                        break
                                                    }
                                                }
                                                withAnimation{
                                                    self.selectedIncExpIndex.toggle()
                                                    if self.selectedCategoryIndex {
                                                        self.selectedCategoryIndex.toggle()
                                                    }
                                                }
                                            }
                                            Spacer()
                                        }
                                    }.accentColor(Color.text_primary_color).frame(height: 50)
                                }
                            }.accentColor(Color.text_primary_color).padding(.vertical, 10).padding(.horizontal, 16).background(Color.secondary_color).cornerRadius(4)
                            
                            DisclosureGroup("\(categoryText?.title ?? "")", isExpanded: $selectedCategoryIndex){
                                VStack{
                                    ForEach(categories){ category in
                                        if typeText[1] == "-" && category.type == "-" {
                                            HStack{
                                                Text("\(category.title)").onTapGesture {
                                                    self.categoryText = category
                                                    withAnimation{
                                                        self.selectedCategoryIndex.toggle()
                                                        if self.selectedIncExpIndex {
                                                            self.selectedIncExpIndex.toggle()
                                                        }
                                                    }
                                                }
                                                Spacer()
                                            }
                                        }else if typeText[1] == "+" && category.type == "+"{
                                            HStack{
                                                Text("\(category.title)").onTapGesture {
                                                    self.categoryText = category
                                                    withAnimation{
                                                        self.selectedCategoryIndex.toggle()
                                                        if self.selectedIncExpIndex {
                                                            self.selectedIncExpIndex.toggle()
                                                        }
                                                    }
                                                }
                                                Spacer()
                                            }
                                        }
                                    }.accentColor(Color.text_primary_color).frame(height: 50)
                                }
                            }.accentColor(Color.text_primary_color).padding(.vertical, 10).padding(.horizontal, 16).background(Color.secondary_color).cornerRadius(4)
                            
                            Group{
                                HStack {
                                    DatePicker("PickerView", selection: $occuredOnDatePicker,
                                               displayedComponents: [.date, .hourAndMinute]).labelsHidden().padding(.leading, 16).accentColor(Color.text_primary_color)
                                    Spacer()
                                }
                                .frame(height: 50).frame(maxWidth: .infinity)
                                .background(Color.secondary_color).cornerRadius(4)
                                
                                TextField("Заметка", text: $note)
                                    .accentColor(Color.text_primary_color)
                                    .frame(height: 50).padding(.leading, 16)
                                    .background(Color.secondary_color)
                                    .cornerRadius(4)
                                
                                
                            }
                        }
                        Button(action: {
                            
                            if let actualAmount = Double(self.amount){
                                let transaction = Transaction(id: UUID().uuidString, amount: actualAmount, category: categoryText, type: typeText[1], date: occuredOnDatePicker, note: note)
                                if let i = index{
                                    DatabaseManager.shared.updateTransactionToWallet(id: i, transaction: transaction)
                                }else{
                                    DatabaseManager.shared.addTransactionToWallet(transaction)
                                }
                                isPresented = false
                            }else{
                                self.message = "Некоректное значение"
                                self.alert.toggle()                            }
                        }) {
                            
                            RoundedRectangle(cornerRadius: 5).frame(width: 250, height: 50).foregroundColor(Color.primary_back).overlay(
                                Text(index == nil ? "Создать транзакцию" : "Сохранить измнения").foregroundColor(.primary_color)
                            )
                        }.padding()
                    }
                }
            }
            .alert(isPresented: $alert) {
                Alert(title: Text("Ошибка"), message: Text(self.message), dismissButton: .default(Text("Ok")))
            }
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarItems(leading: leadingBarButtonItems)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text(index == nil ? "Создать транзакцию" : "Изменить транзакцию").font(.headline)
                    
                }
                
            }
        }    .navigationBarColor(backgroundColor: UIColor.primary_color!, tintColor: UIColor.primary_color!).dismissKeyboardOnTap()
        .navigationViewStyle(StackNavigationViewStyle()).onAppear{
            if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
                if let user = DatabaseManager.shared.getUser(id: userId){
                    self.categories = user.categories.toArray()
                    if index == nil{
                        self.categoryText = self.categories[0]
                    }
                }
            }
            UIApplication.shared.windows.first?.rootViewController?.view.overrideUserInterfaceStyle = UserDefaults.standard.bool(forKey: "ColorApp") ? .dark : .light
        }
        
    }
}




