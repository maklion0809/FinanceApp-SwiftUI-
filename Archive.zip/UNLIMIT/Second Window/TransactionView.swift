//
//  TransactionView.swift
//  UNLIMITApp
//
//  Created by Тимофей on 26.04.2021.
//

import SwiftUI

struct TransactionView: View {
    
    var transactions: Transaction?
    
    var body: some View {

            HStack {
                
                Text((transactions?.category!.title)!)
                
                Spacer()
                
                Text(transactions!.date.dateAndTimetoString())
                
                Spacer()
                
                Text("\(transactions!.type)\(transactions!.amount, specifier: "%.2f")")
                    .foregroundColor(transactions!.type.elementsEqual("-") ? Color(#colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0, alpha: 1)) : Color(#colorLiteral(red: 0.3912505507, green: 0.7258948088, blue: 0.3816880286, alpha: 1)))
                
            }
    }
}
