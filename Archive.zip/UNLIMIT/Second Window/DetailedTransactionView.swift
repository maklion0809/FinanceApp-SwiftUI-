//
//  DetailedTransactionView.swift
//  UNLIMITApp
//
//  Created by Тимофей on 18.05.2021.
//

import SwiftUI

struct DetailedTransactionView: View {
    
    @State var showUpdateTransaction = false
    
    @Binding var isPresented: Bool
    
    @State var transaction: Transaction
    
    var index: Int
    
    @State var showConfirm = false
    
    private var leadingBarButtonItems: some View {
        Button(action: {
            isPresented = false
        }){
            Image(systemName: "arrow.left").font(.title2).foregroundColor(.primary)
        }
    }
    private var traillingBarButtonItems: some View {
        Button(action: {
            self.showConfirm.toggle()
        }){
            Image(systemName: "trash").font(.title2).foregroundColor(.primary)
        }
    }
    var body: some View {
        NavigationView {
            ZStack{
                Color.primary_color.edgesIgnoringSafeArea(.all)
                VStack{
                    ScrollView(showsIndicators: false){
                        
                        VStack(spacing: 12){
                            Image("transaction").resizable().aspectRatio(contentMode: .fit).frame(width: 200, height: 200, alignment: .center)
                            
                            Text("Сумма: \(transaction.amount, specifier: "%.2f")")
                                .accentColor(Color.text_primary_color)
                                .frame(height: 50).padding(.leading, 16)
                            Text("Тип: \(getType(symbol: transaction.type)[0])")
                                .accentColor(Color.text_primary_color)
                                .frame(height: 50).padding(.leading, 16)
                            
                            Text("Кaтегория: \(transaction.category?.title ?? "")")
                                .accentColor(Color.text_primary_color)
                                .frame(height: 50).padding(.leading, 16)
                            
                            Text("Дaтa: \(transaction.date.dateAndTimetoString())")
                                .accentColor(Color.text_primary_color)
                                .frame(height: 50).padding(.leading, 16)
                            if let note = transaction.note, note != ""{
                                Text("Зaметкa: \(note)")
                                    .accentColor(Color.text_primary_color)
                                    .frame(height: 50).padding(.leading, 16)
                            }
                        }
                    }
                }
                VStack{
                    Spacer()
                    HStack{
                        Spacer()
                        Button(action: {
                            showUpdateTransaction.toggle()
                        }){
                            Text("Изменить")
                        }.padding(.all, 50).fullScreenCover(isPresented: $showUpdateTransaction){
                            AddTransaction(isPresented: $showUpdateTransaction, occuredOnDatePicker: transaction.date,note: transaction.note ?? "",  amount: String(transaction.amount), categoryText: transaction.category!,typeText: getType(symbol: transaction.type), index: index)
                        }
                    }
                }
                
            }
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarItems(leading: leadingBarButtonItems, trailing: traillingBarButtonItems)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("Детали транзакции").font(.headline)
                    
                }
                
            }.alert(isPresented: $showConfirm) {
                Alert(title: Text("Удалить"), message: Text("Вы уверены?"),
                      primaryButton: .cancel(Text("Отмена")),
                      secondaryButton: .destructive(Text("Удалить")) {
                        DispatchQueue.main.asyncAfter(deadline: .now()) {
                            DatabaseManager.shared.deleteTransactionToWallet(id: index)
                            isPresented = false
                        }
                      })
            }
        }    .navigationBarColor(backgroundColor: .primary_color!, tintColor: .primary_color!).dismissKeyboardOnTap()
        .navigationViewStyle(StackNavigationViewStyle()).onChange(of: showUpdateTransaction) { _ in
            if let indexUser = UserDefaults.standard.string(forKey: "ChooseUser"){
                if let user = DatabaseManager.shared.getUser(id: indexUser){
                    if let indexWallet = UserDefaults.standard.object(forKey: "ChooseWallet"){
                        self.transaction = user.wallets[indexWallet as! Int].transactions[index]
                    }
                }
            }
        }
    }
    func getType(symbol: String) -> [String] {
        if symbol == "-" {
            return ["Расходы", symbol]
        }else{
            return ["Доходы", symbol]
        }
    }
}
