//
//  SecondWindow.swift
//  UNLIMITApp
//
//  Created by Тимофей on 27.04.2021.
//

import SwiftUI
import ConfettiSwiftUI

struct SecondWindow: View {
    
    @State var isLoading = true
    
    @State var confetti: Int = 0
    
    @State private var showingAddTransaction = false
    @State private var showingSettingTransaction = false
    
    
    @State var chooseIndex: Int?
    @State var chooseTransaction: Transaction?
    
    
    @State var  searchQuery = ""
    
    @Environment(\.colorScheme) var scheme
    
    @State var transactions: [Transaction] = []
    
    var sortTransactions: [[Transaction]] = [[]]
    
    private var trailingBarButtonItems: some View {
        Button(action: {
            withAnimation{
                self.showingAddTransaction = true
            }
        }){
            Image(systemName: "plus").font(.title2).foregroundColor(.primary)
        }.fullScreenCover(isPresented: $showingAddTransaction) {
            AddTransaction(isPresented: $showingAddTransaction)
        }
    }
    
    
    
    var body: some View{
        
        NavigationView {
            VStack{
                
                if transactions.count == 0{
                    
                    LottieView(animType: .empty_face).frame(width: 300, height: 300).transition( AnyTransition.asymmetric(insertion: .scale, removal: .opacity))
                    VStack {
                        Text("Еще нет транзакций!").foregroundColor(Color.text_primary_color)
                        Text("Добавьте транзакцию, и она появится здесь").foregroundColor(Color.text_secondary_color).padding(.top, 2)
                    }.padding(.horizontal).transition( AnyTransition.asymmetric(insertion: .scale, removal: .opacity))
                    Spacer()
                }else{
                    
                    if isLoading{
                        
                        ProgressView().progressViewStyle(CircularProgressViewStyle(tint: .blue)).scaleEffect(3)
                        
                    }else{
                        ZStack{
                            
                            VStack{
                                
                                HStack(spacing: 15){
                                    Image(systemName: "magnifyingglass").font(.system(size: 23, weight: .bold)).foregroundColor(.gray)
                                    TextField("Введите категорию, дату или сумму...", text: $searchQuery)
                                    if searchQuery != ""{
                                        Button(action: {
                                            self.searchQuery = ""
                                        }){
                                            Image(systemName: "xmark.circle").font(.system(size: 23)).foregroundColor(.gray)
                                        }
                                    }
                                }.padding(.vertical, 10).padding(.horizontal).background(Color.primary.opacity(0.05)).cornerRadius(8).padding()
                                List{
                                    ForEach(Array(zip(transactions.indices, searchQuery == "" ? transactions: !transactions.filter{$0.category!.title.lowercased().contains(searchQuery.lowercased())}.isEmpty ? transactions.filter{$0.category!.title.lowercased().contains(searchQuery.lowercased())} : !transactions.filter{($0.type + String($0.amount)).lowercased().contains(searchQuery.lowercased())}.isEmpty ? transactions.filter{( $0.type + String($0.amount)).lowercased().contains(searchQuery.lowercased())} : transactions.filter{$0.date.dateAndTimetoString().lowercased().contains(searchQuery.lowercased())})), id: \.0){ index, item in
                                        TransactionView(transactions: item).onTapGesture {
                                            self.showingSettingTransaction.toggle()
                                            self.chooseIndex = index
                                            self.chooseTransaction = item
                                        }.fullScreenCover(isPresented: $showingSettingTransaction){
                                            DetailedTransactionView(isPresented: $showingSettingTransaction, transaction: chooseTransaction!, index: chooseIndex!)
                                        }
                                    }
                                }.transition (.move (edge: .leading))
                            }
                            VStack{
                                HStack{
                                    ConfettiCannon(counter: $confetti, num: 100, confettis: [.text("💵"), .text("💶"), .text("💷"), .text("💴")], confettiSize: 30, openingAngle: Angle(degrees: 0), closingAngle: Angle(degrees: 360), radius: 200).animation(.easeOut(duration: 3))
                                }
                                Spacer()
                            }
                        }
                    }
                }
            }.navigationBarTitleDisplayMode(.inline).navigationBarHidden(searchQuery == "" ? false : true).animation(.spring())
            .navigationBarItems(trailing: trailingBarButtonItems)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("Транзакции").font(.headline)
                    
                }
                
            }
        }.navigationBarColor(backgroundColor: UIColor.primary_color!, tintColor: UIColor.primary_color!).dismissKeyboardOnTap()
        .navigationViewStyle(StackNavigationViewStyle()).onAppear{
            getData()
        }.onChange(of: showingAddTransaction){_ in
            confetti += 1
            getData()
            
        }.onChange(of: showingSettingTransaction){_ in
            getData()
        }
    }
    func getData(){
        if let indexUser = UserDefaults.standard.string(forKey: "ChooseUser"){
            if let user = DatabaseManager.shared.getUser(id: indexUser){
                if let indexWallet = UserDefaults.standard.object(forKey: "ChooseWallet"){
                    self.transactions = user.wallets[indexWallet as! Int].transactions.toArray()
                    isLoading = false
                }
            }
        }
    }
}


