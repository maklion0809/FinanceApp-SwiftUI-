//
//  PageController.swift
//  UNLIMIT
//
//  Created by Тимофей on 16.04.2021.
//

import SwiftUI

struct PageController: UIViewRepresentable {
    
    var numberofPages: Int
    @Binding var currentPage: Int
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    func makeUIView(context: Context) -> UIPageControl {
        let control = UIPageControl()
        control.numberOfPages = numberofPages
        control.pageIndicatorTintColor = UIColor.darkGray
        control.currentPageIndicatorTintColor = UIColor.systemGray5
        control.frame(forAlignmentRect: CGRect(origin: .zero, size: CGSize(width: 30, height: 30)))
        control.addTarget(context.coordinator, action: #selector(Coordinator.updateCurrentPage(sender:)), for: .valueChanged)
        
        return control
    }
    
    func updateUIView(_ uiView: UIPageControl, context: Context) {
        uiView.currentPage = currentPage
    }
    
    class Coordinator: NSObject{
        var control : PageController
        
        init(_ control: PageController) {
            self.control = control
        }
        
        @objc func updateCurrentPage(sender: UIPageControl){
            control.currentPage = sender.currentPage
        }
    }
    
}

