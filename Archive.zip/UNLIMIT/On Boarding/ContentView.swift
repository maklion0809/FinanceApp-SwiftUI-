//
//  ContentView.swift
//  UNLIMIT
//
//  Created by Тимофей on 16.04.2021.
//

import SwiftUI

struct ContentView: View {
    
    @State var isOnboardingDone = false
    
    var body: some View {
        Group{
            PageView(cards.map { OnboardingCardView(card: $0) }, isOnboardingDone: $isOnboardingDone)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
