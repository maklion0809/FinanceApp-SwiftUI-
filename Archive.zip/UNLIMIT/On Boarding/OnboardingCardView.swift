//
//  OnboardingCardView.swift
//  UNLIMIT
//
//  Created by Тимофей on 16.04.2021.
//

import SwiftUI

struct OnboardingCardView: View {
    
    var card: OnboardingCard
    
    var body: some View {
        VStack{
            Image(card.image).resizable().aspectRatio(contentMode: .fit).frame(width: 300, height: 300, alignment: .center)
            Text(card.title).font(.title).fontWeight(.bold).foregroundColor(.primary).padding([.top, .bottom])
            Text(card.description).lineLimit(5).multilineTextAlignment(.center).font(.body).foregroundColor(.secondary).padding()
        }.padding()
    }
}

struct OnboardingCardView_Previews: PreviewProvider {
    static var previews: some View {
        OnboardingCardView(card: cards[0])
    }
}
