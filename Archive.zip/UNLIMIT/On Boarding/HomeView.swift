//
//  HomeView.swift
//  UNLIMIT
//
//  Created by Тимофей on 16.04.2021.
//

import SwiftUI

struct HomeView: View {
        
    @State var index = 0
    @State var expand = false
    
    init() {
        UIApplication.shared.windows.first?.rootViewController?.view.overrideUserInterfaceStyle = UserDefaults.standard.bool(forKey: "ColorApp") ? .dark : .light
        
    }

    
    var body: some View{
        VStack{
            Text("")
            ZStack(alignment: .bottom){
                switch index{
                    case 0:
                        FirstWindow(viewModel: FirstWindowModel())
                    case 1:
                        SecondWindow()
                    case 2:
                        ThirdWindow()
                    case 3:
                        FourthWindow(appSettingsVM: AppSettingsViewModel())
                    default:
                        Text("Error")
                }
    
            }.clipped()
            TabBar(index: self.$index, expand: self.$expand)
        }.edgesIgnoringSafeArea(.top)
    }
}


struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}

class Host: UIHostingController<ContentView>{
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return .lightContent
    }
}

struct  TabBar: View {
    
    @Binding var index: Int
    @Binding var expand: Bool
    
    @State private var showingAddTransaction = false
    
    var body: some View{
        HStack(spacing: 0){
            Button(action:{
                self.index = 0

            }){
                Image(systemName: "house.fill").resizable().frame(width: 25, height: 25).foregroundColor(self.index == 0 ? Color.primary_back : Color.primary_back.opacity(0.3))
            }
            
            Spacer(minLength: 0)
            
            Button(action:{
                self.index = 1
            }){
                Image(systemName: "cart.fill").resizable().frame(width: 25, height: 25).foregroundColor(self.index == 1 ? Color.primary_back : Color.primary_back.opacity(0.3))
            }
            
            Spacer()
            
            Button(action:{
                
                withAnimation{
                    self.showingAddTransaction = true
                }

            }){
                Image(systemName: "plus").font(.title).foregroundColor(Color.primary_back).padding().background(Color.primary_color).clipShape(Circle()).shadow(radius: 4)
            }.offset(y: -20).fullScreenCover(isPresented: $showingAddTransaction) {
                AddTransaction(isPresented: $showingAddTransaction)
            }
            
            Spacer(minLength: 0)
            
            Button(action:{
                self.index = 2
            }){
                Image(systemName: "bag.fill").resizable().frame(width: 25, height: 25).foregroundColor(self.index == 2 ? Color.primary_back : Color.primary_back.opacity(0.3))
            }
            
            Spacer(minLength: 0)
            
            Button(action:{
                self.index = 3
            }){
                Image(systemName: "gear").resizable().frame(width: 25, height: 25).foregroundColor(self.index == 3 ? Color.primary_back : Color.primary_back.opacity(0.3))
            }
        }.padding(.horizontal, 35).padding(.top, 10).padding(.bottom, UIApplication.shared.windows.first?.safeAreaInsets.bottom == 0 ? 10 : 0).padding(.top, -10)
    }
}
