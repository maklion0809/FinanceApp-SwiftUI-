//
//  CreateToAccount.swift
//  UNLIMITApp
//
//  Created by Тимофей on 23.04.2021.
//

import SwiftUI

struct SignIn : View {
    
    @State var email = ""
    @State private var isEditingEmail: Bool = false
    @State var pass = ""
    @State private var isEditingPass: Bool = false
    @State var message = ""
    @State var alert = false
    @State var show = false
    @State var showingHomeView = false
    
    var body : some View{
        VStack {
            VStack{
                Image("auth_icon").resizable().aspectRatio(contentMode: .fit).frame(width: 300, height: 300, alignment: .center)
                
                VStack(alignment: .leading){
                        
                        
                    VStack (alignment: .leading){
                        Text("Email").foregroundColor(self.isEditingPass == false ? .gray : .black)
                                    .scaleEffect((self.email == "" && self.isEditingEmail == false) ? 1 : 0.75)
                                    .offset(y: (self.email == "" && self.isEditingEmail == false ) ? 35 : 0)
                                    .animation(.spring())
                                TextField("", text: $email)
                                Divider()
                    }.padding().onTapGesture {
                                    self.isEditingEmail.toggle()
                                    if(self.isEditingEmail == false){
                                        UIApplication.shared.endEditing()
                                    }
                            }
                    
                        
                        VStack (alignment: .leading){
                            Text("Password").foregroundColor(self.isEditingPass == false ? .gray : .black)
                                        .scaleEffect((self.pass == "" && self.isEditingPass == false) ? 1 : 0.75)
                                        .offset(y: (self.pass == "" && self.isEditingPass == false ) ? 35 : 0)
                                        .animation(.spring())
                                    SecureField("", text: $pass )
                                    Divider()
                                }.padding()
                                    .onTapGesture {
                                        self.isEditingPass.toggle()
                                        if(self.isEditingPass == false){
                                            UIApplication.shared.endEditing()
                                        }
                                }
                    
                }.padding(.horizontal, 6).padding(.bottom, 50)
                
                Button(action: {
                    if let user = DatabaseManager.shared.signInUser(email: email, password: pass){
                        UserDefaults.standard.set(user, forKey: "ChooseUser")
                        UserDefaults.standard.set(0, forKey: "ChooseWallet")
                        self.showingHomeView.toggle()
                    }else{
                        self.message = "Неверный email или пароль"
                        self.alert.toggle()
                    }
                    
                }) {
                    
                    RoundedRectangle(cornerRadius: 5).frame(width: 250, height: 50).foregroundColor(Color.black).overlay(
                        Text("Войти в аккаунт").foregroundColor(.white)
                    )
                    
                }.fullScreenCover(isPresented: $showingHomeView, content: {
                    HomeView()
                })
                
            }.padding()
                .alert(isPresented: $alert) {
                    Alert(title: Text("Ошибка!"), message: Text(self.message), dismissButton: .default(Text("Ok")))
            }
            VStack{
                
                Text("(или)").foregroundColor(Color.gray.opacity(0.5)).padding(.top,30)
                
                
                HStack(spacing: 8){
                                        
                    Text("У вас нет аккаунта? ").foregroundColor(Color.gray.opacity(0.5))
                    
                    Button(action: {
                        
                        self.show.toggle()
                        
                    }) {
                        
                        Text("Зарегистрироваться")
                        
                    }.foregroundColor(.blue).fullScreenCover(isPresented: $show) {
                        
                        SignUp(show: self.show)
                    }
                    
                }.padding(.top, 25)
                
            }
        }
    }
}

struct SignUp : View {
    
    @State var email = ""
    @State private var isEditingEmail: Bool = false
    @State var pass = ""
    @State private var isEditingPass: Bool = false
    @State var repass = ""
    @State private var isEditingRepass: Bool = false
    @State var message = ""
    @State var error : String = ""
    @State var alert = false
    @State var show = false
    @State private var showingHoveView = false
    
    let categories: [Category] = [Category(title: "Аванс", type: "+", system: true), Category(title: "Грант", type: "+", system: true) ,Category(title: "Запралата", type: "+", system: true),Category(title: "Пенсия", type: "+", system: true), Category(title: "Подарок", type: "+", system: true), Category(title: "Помощь", type: "+", system: true), Category(title: "Премия", type: "+", system: true), Category(title: "Призы", type: "+", system: true) ,Category(title: "Социальная помощь", type: "+", system: true), Category(title: "Стипендия", type: "+", system: true), Category(title: "Автомобиль", type: "-", system: true), Category(title: "Благотворительность", type: "-", system: true), Category(title: "Бытовая техника", type: "-", system: true), Category(title: "Дети", type: "-", system: true), Category(title: "Домашние животные", type: "-", system: true), Category(title: "Здоровье и красота", type: "-", system: true), Category(title: "Долг", type: "-", system: true), Category(title: "Квартира", type: "-", system: true), Category(title: "Налоги", type: "-", system: true), Category(title: "Образование", type: "-", system: true), Category(title: "Одежда", type: "-", system: true), Category(title: "Отдых", type: "-", system: true), Category(title: "Еда", type: "-", system: true), Category(title: "Разное", type: "-", system: true), Category(title: "Ремонт", type: "-", system: true), Category(title: "Товары для дома", type: "-", system: true), Category(title: "Транспорт", type: "-", system: true), Category(title: "Хоби", type: "-", system: true)]
    
    @Environment(\.presentationMode) var presentationMode
    
    @State private var showWallet = false
    
    var body : some View{
        VStack{
            
            HStack(){
                Button(action: {
                    self.presentationMode.wrappedValue.dismiss()
                }){
                    Image(systemName: "arrow.left").font(.title2).foregroundColor(.primary)
                }
                Spacer()
            }.padding(.leading, 16)
            Spacer()
            
            Image("auth_icon").resizable().aspectRatio(contentMode: .fit).frame(width: 300, height: 300, alignment: .center)

            VStack(alignment: .leading){
                
                
                VStack (alignment: .leading){
                    Text("Email").foregroundColor(self.isEditingPass == false ? .gray : .black)
                                .scaleEffect((self.email == "" && self.isEditingEmail == false) ? 1 : 0.75)
                                .offset(y: (self.email == "" && self.isEditingEmail == false ) ? 35 : 0)
                                .animation(.spring())
                            TextField("", text: $email)
                            Divider()
                }.padding().onTapGesture {
                                self.isEditingEmail.toggle()
                                if(self.isEditingEmail == false){
                                    UIApplication.shared.endEditing()
                                }
                        }
                
                VStack (alignment: .leading){
                    Text("Password").foregroundColor(self.isEditingPass == false ? .gray : .black)
                                .scaleEffect((self.pass == "" && self.isEditingPass == false) ? 1 : 0.75)
                                .offset(y: (self.pass == "" && self.isEditingPass == false ) ? 35 : 0)
                                .animation(.spring())
                            SecureField("", text: $pass )
                            Divider()
                        }.padding()
                            .onTapGesture {
                                self.isEditingPass.toggle()
                                if(self.isEditingPass == false){
                                    UIApplication.shared.endEditing()
                                }
                        }
                VStack (alignment: .leading){
                    Text("RePassword").foregroundColor(self.isEditingRepass == false ? .gray : .black)
                                .scaleEffect((self.repass == "" && self.isEditingRepass == false) ? 1 : 0.75)
                                .offset(y: (self.repass == "" && self.isEditingRepass == false ) ? 35 : 0)
                                .animation(.spring())
                            SecureField("", text: $repass )
                            Divider()
                        }.padding()
                            .onTapGesture {
                                self.isEditingRepass.toggle()
                                if(self.isEditingRepass == false){
                                    UIApplication.shared.endEditing()
                                }
                        }

                
               
            }.padding(.horizontal, 6).padding(.bottom, 50)
            
            Spacer()
            
            Button(action: {
                if pass == repass{
                    let unIndex = UUID().uuidString
                    let user = User(id: unIndex, email: email, password: pass, categories: categories)
                    DatabaseManager.shared.saveUser(user)
                    UserDefaults.standard.set(unIndex, forKey: "ChooseUser")
                    self.showingHoveView = true
                }else{
                    self.message = "Пароли не совпадают!"
                    self.alert.toggle()
                }
            }) {
                RoundedRectangle(cornerRadius: 5).frame(width: 250, height: 50).foregroundColor(Color.black).overlay(
                    Text("Зарегистрироваться").foregroundColor(.white)
                )
            }.fullScreenCover(isPresented: $showingHoveView, content: {
                AddWallet(auto: true)
            })
            
        }
        .padding()
            .alert(isPresented: $alert) {

                Alert(title: Text("Ошибка!"), message: Text(self.message), dismissButton: .default(Text("Ok")))
        }
    }
}

extension UIApplication {
    func endEditing() {
        sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}

