//
//  PageView.swift
//  UNLIMIT
//
//  Created by Тимофей on 16.04.2021.
//

import SwiftUI

struct PageView<Page: View>: View {
    
    var viewControllers: [UIHostingController<Page>]
    @Binding var isOnboardingDone: Bool
    
    @State var currentPage: Int = 0
        
    @State private var showingLoginToAccount = false
    
    init(_ views: [Page], isOnboardingDone: Binding<Bool>){
        self.viewControllers = views.map{
            UIHostingController(rootView: $0)
        }
        self._isOnboardingDone = isOnboardingDone
    }
    
    var body: some View {
        VStack{
            PageViewController(controllers: viewControllers, currentPage: $currentPage)
            
            PageController(numberofPages: viewControllers.count, currentPage: $currentPage)
            
            Button(action: {
                self.showingLoginToAccount.toggle()
            }){
                RoundedRectangle(cornerRadius: 5).frame(width: 250, height: 50).foregroundColor(Color.black).overlay(
                    Text("Get start").foregroundColor(.white))
            }.fullScreenCover(isPresented: $showingLoginToAccount, content: {
                SignIn()
            })
        }
    }
}

struct PageView_Previews: PreviewProvider {
    static var previews: some View {
        PageView(cards.map {
            OnboardingCardView(card: $0)
        }, isOnboardingDone: .constant(false))
    }
}
