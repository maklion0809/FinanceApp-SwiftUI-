//
//  OnboardingCard.swift
//  UNLIMIT
//
//  Created by Тимофей on 16.04.2021.
//

import SwiftUI

struct OnboardingCard: Identifiable{
    var id = UUID()
    var image: String
    var title: String
    var description: String
}

var cards: [OnboardingCard] = [OnboardingCard(image: "Analysys", title: "Управление расходами", description: "Отслеживайте свои расходы, просматривайте их распределение по категориям"),OnboardingCard(image: "Budgeting", title: "Контроль бюджетов", description: "Задавайте бюджеты на выбраные категории расходов"),OnboardingCard(image: "Budgeting", title: "Помнить долги", description: "Создавайте долги, что поможет помнить о них"),OnboardingCard(image: "Budgeting", title: "Достигать целей", description: "Создавайте цели, чтобы достичь поставленных финансовых целей"),OnboardingCard(image: "security", title: "Давайте начнем!", description: "Никогда не было лучшего времени, чем сейчас, чтобы начать думать о том, как с легкостью управлять всеми своими финансами")]
