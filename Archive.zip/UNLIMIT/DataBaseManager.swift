//
//  DataBaseManager.swift
//  FinanceApp
//
//  Created by Тимофей on 29.05.2021.
//

import RealmSwift
import Foundation

class DatabaseManager {
    
    private let database: Realm
    
    static let shared: DatabaseManager = DatabaseManager()
    
    private init() {
        database = try! Realm()
    }
    
    func multiThreadedRealm() -> Realm {
        return try! Realm(configuration: database.configuration)
    }

}
// MARK: get
extension DatabaseManager {

    func saveUser(_ user: User) {
        saveRealmObject(user)
    }
    func getUser(id: String) -> User?{
        database.object(ofType: User.self, forPrimaryKey: id)
    }
    func deleteUser(id: String) -> Bool{
        
        if let user = getUser(id: id){
            deleteRealmObject(user)
            return true
        }else{
            print("SomeError")
        }
        return false
    }
    func signInUser(email: String, password: String) -> String?{
        let users = database.objects(User.self)
        print(users)
        for i in users{
            if i.email == email && i.password == password{
                return i.id
            }
        }
        return nil
    }
}

extension DatabaseManager{
    // MARK: add
    func saveRealmObject(_ object: Object){
        do {
            try database.write {
                database.add(object, update: .modified)
            }
        } catch {
            print("Save action failed: \(error)")
        }
    }
    func addWalletToUser(_ wallet: Wallet){
        if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
            if let user = DatabaseManager.shared.getUser(id: userId){
                do{
                    try database.write{
                        user.wallets.append(wallet)
                        UserDefaults.standard.setValue((user.wallets.count - 1), forKey: "ChooseWallet")
                        database.add(user, update: .modified)
                    }
                }catch{
                    print("Save action failed: \(error)")
                }
            }
        }
    }
    func AddCategoriesToUser(_ categories: [Category]){
        if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
            if let user = DatabaseManager.shared.getUser(id: userId){
                do{
                    try database.write{
                        for item in categories{
                            user.categories.append(item)
                        }
                        database.add(user, update: .modified)
                    }
                }catch{
                    print("Save action failed: \(error)")
                }
            }
        }
    }
    func addCategoryToUser(_ category: Category){
        if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
            if let user = DatabaseManager.shared.getUser(id: userId){
                do{
                    try database.write{
                        user.categories.append(category)
                        database.add(user, update: .modified)
                    }
                }catch{
                    print("Save action failed: \(error)")
                }
            }
        }
    }
    func addGoalToUser(_ goal: Goal){
        if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
            if let user = DatabaseManager.shared.getUser(id: userId){
                do{
                    try database.write{
                        user.goals.append(goal)
                        database.add(user, update: .modified)
                    }
                }catch{
                    print("Save action failed: \(error)")
                }
            }
        }
    }
    func addDebtToUser(_ debt: Debt){
        if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
            if let user = DatabaseManager.shared.getUser(id: userId){
                do{
                    try database.write{
                        user.debts.append(debt)
                        database.add(user, update: .modified)
                    }
                }catch{
                    print("Save action failed: \(error)")
                }
            }
        }
    }
    
    func addTransactionToWallet(_ transaction: Transaction){
        if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
            if let user = DatabaseManager.shared.getUser(id: userId){
                if let walletId = UserDefaults.standard.object(forKey: "ChooseWallet"){
                    do{
                        try database.write{
                            if transaction.type == "-"{
                                user.wallets[walletId as! Int].balance -= transaction.amount
                            }else{
                                user.wallets[walletId as! Int].balance += transaction.amount
                            }
                            user.wallets[walletId as! Int].transactions.append(transaction)
                            database.add(user, update: .modified)
                        }
                    }catch{
                        print("Save action failed: \(error)")
                    }
                }
            }
        }
    }
    func addBudgetToWallet(_ budget: Budget){
        if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
            if let user = DatabaseManager.shared.getUser(id: userId){
                if let walletId = UserDefaults.standard.object(forKey: "ChooseWallet"){
                    do{
                        try database.write{
                            user.wallets[walletId as! Int].budgets.append(budget)
                            database.add(user, update: .modified)
                        }
                    }catch{
                        print("Save action failed: \(error)")
                    }
                }
            }
        }
    }
}
    // MARK: update
extension DatabaseManager{
    func updateWalletToUser(id: Int, wallet: Wallet){
        if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
            if let user = DatabaseManager.shared.getUser(id: userId){
                do{
                    try database.write{
                        user.wallets[id] = wallet
                        database.add(user, update: .modified)
                    }
                }catch{
                    print("Save action failed: \(error)")
                }
            }
        }
    }
    func updateDebtToUser(id: Int, complite: Bool){
        if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
            if let user = DatabaseManager.shared.getUser(id: userId){
                do{
                    try database.write{
                        user.debts[id].complite = complite
                        database.add(user, update: .modified)
                    }
                }catch{
                    print("Save action failed: \(error)")
                }
            }
        }
    }
    func updateGoalToUser(id: Int, complite: Bool){
        if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
            if let user = DatabaseManager.shared.getUser(id: userId){
                do{
                    try database.write{
                        user.goals[id].complite = complite
                        database.add(user, update: .modified)
                    }
                }catch{
                    print("Save action failed: \(error)")
                }
            }
        }
    }
    func updateCategoryToUser(id: Int, category: Category){
        if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
            if let user = DatabaseManager.shared.getUser(id: userId){
                do{
                    try database.write{
                        user.categories[id] = category
                        database.add(user, update: .modified)
                    }
                }catch{
                    print("Save action failed: \(error)")
                }
            }
        }
    }
    func updateTransactionToWallet(id: Int, transaction: Transaction){
        if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
            if let user = DatabaseManager.shared.getUser(id: userId){
                if let walletId = UserDefaults.standard.object(forKey: "ChooseWallet"){
                    do{
                        try database.write{
                            if transaction.type == "-"{
                                user.wallets[walletId as! Int].balance -= transaction.amount - user.wallets[walletId as! Int].transactions[id].amount
                            }else{
                                user.wallets[walletId as! Int].balance += transaction.amount - user.wallets[walletId as! Int].transactions[id].amount
                            }
                            user.wallets[walletId as! Int].transactions[id] = transaction
                            database.add(user, update: .modified)
                        }
                    }catch{
                        print("Save action failed: \(error)")
                    }
                }
            }
        }
    }
    func updateBudgetToWallet(id: Int, budget: Budget){
        if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
            if let user = DatabaseManager.shared.getUser(id: userId){
                if let walletId = UserDefaults.standard.object(forKey: "ChooseWallet"){
                    do{
                        try database.write{
                            user.wallets[walletId as! Int].budgets[id] = budget
                            database.add(user, update: .modified)
                        }
                    }catch{
                        print("Save action failed: \(error)")
                    }
                }
            }
        }
    }
}
    // MARK: delete
extension DatabaseManager{
    func deleteRealmObject<T: Object>(_ object: T){
        do{
            try database.write{
                database.delete(database.objects(T.self))
            }
        }catch {
            print("")
        }
    }
    func deleteWalletToUser(id: Int){
        if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
            if let user = DatabaseManager.shared.getUser(id: userId){
                do{
                    try database.write{
                        user.wallets.remove(at: id)
                        database.add(user, update: .modified)
                    }
                }catch{
                    print("Save action failed: \(error)")
                }
            }
        }
    }
    func deleteDebtToUser(id: Int){
        if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
            if let user = DatabaseManager.shared.getUser(id: userId){
                do{
                    try database.write{
                        user.debts.remove(at: id)
                        database.add(user, update: .modified)
                    }
                }catch{
                    print("Save action failed: \(error)")
                }
            }
        }
    }
    func deleteGoalToUser(id: Int){
        if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
            if let user = DatabaseManager.shared.getUser(id: userId){
                do{
                    try database.write{
                        user.goals.remove(at: id)
                        database.add(user, update: .modified)
                    }
                }catch{
                    print("Save action failed: \(error)")
                }
            }
        }
    }
    func deleteCategoryToUser(id: Int){
        if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
            if let user = DatabaseManager.shared.getUser(id: userId){
                do{
                    try database.write{
                        user.categories.remove(at: id)
                        database.add(user, update: .modified)
                    }
                }catch{
                    print("Save action failed: \(error)")
                }
            }
        }
    }
    func deleteTransactionToWallet(id: Int){
        if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
            if let user = DatabaseManager.shared.getUser(id: userId){
                if let walletId = UserDefaults.standard.object(forKey: "ChooseWallet"){
                    do{
                        try database.write{
                            if user.wallets[walletId as! Int].transactions[id].type == "-"{
                                user.wallets[walletId as! Int].balance += user.wallets[walletId as! Int].transactions[id].amount
                            }else{
                                user.wallets[walletId as! Int].balance -= user.wallets[walletId as! Int].transactions[id].amount
                            }
                            user.wallets[walletId as! Int].transactions.remove(at: id)
                            database.add(user, update: .modified)
                        }
                    }catch{
                        print("Save action failed: \(error)")
                    }
                }
            }
        }
    }
    func deleteBudgetToWallet(id: Int){
        if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
            if let user = DatabaseManager.shared.getUser(id: userId){
                if let walletId = UserDefaults.standard.object(forKey: "ChooseWallet"){
                    do{
                        try database.write{
                            user.wallets[walletId as! Int].budgets.remove(at: id)
                            database.add(user, update: .modified)
                        }
                    }catch{
                        print("Save action failed: \(error)")
                    }
                }
            }
        }
    }
}
