//
//  Array.swift
//  UNLIMIT
//
//  Created by Тимофей on 07.06.2021.
//

import Foundation
import RealmSwift

extension List {
    func toArray() -> [Element] {
      return compactMap {
        $0
      }
    }
 }
