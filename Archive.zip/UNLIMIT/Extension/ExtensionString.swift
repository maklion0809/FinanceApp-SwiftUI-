//
//  ExtensionString.swift
//  UNLIMIT
//
//  Created by Тимофей on 11.06.2021.
//

import Foundation
import SwiftUI

extension String {
   func widthOfString(usingFont font: UIFont) -> CGFloat {
        let fontAttributes = [NSAttributedString.Key.font: font]
        let size = self.size(withAttributes: fontAttributes)
        return size.width
    }
}
