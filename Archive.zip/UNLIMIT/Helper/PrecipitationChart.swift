//
//  PrecipitationChart.swift
//  UNLIMIT
//
//  Created by Тимофей on 11.06.2021.
//

import SwiftUI

struct PrecipitationChart: View {
    
    var wallet: Wallet
    
    var sum: [Double] = []
    
    var body: some View {
        HStack {
          // 2
          ForEach(0..<12) { month in
            // 3
            VStack {
              // 4
              Spacer()
              Text("\(self.sumPrecipitation(month), specifier: "%.2f")")
                .font(.footnote)
                .rotationEffect(.degrees(-90)).fixedSize()
                .frame(width: 20, height: String(format: "%.2f", self.sumPrecipitation(month)).widthOfString(usingFont: UIFont.systemFont(ofSize: 17, weight: .bold)))
               // .zIndex(1)
              // 5
              Rectangle()
                .fill(Color.primary_back)
                .frame(width: 20, height: getHeight(month: month)).cornerRadius(10)
              
              // 6
              Text("\(self.monthAbbreviationFromInt(month))")
                .font(.footnote)
                .frame(height: 20)
            }
          }
        }
    }
    func getHeight(month: Int) -> CGFloat{
        if self.sumPrecipitation(month) == 0{
            return 1
        }else{
            print("-+" + "\(CGFloat((100*Double(1/self.sumPrecipitation(month)))))")
            return CGFloat(200 - ((self.sumPrecipitation(month) - 200)/self.sumPrecipitation(month)/10))
        }
    }
    func monthAbbreviationFromInt(_ month: Int) -> String {
        let ma = Calendar.current.shortMonthSymbols
      return ma[month]
    }
    func sumPrecipitation(_ month: Int) -> Double {
        var sum = Double(0)
        for item in wallet.transactions{
            if Calendar.current.component(.month, from: item.date) == month + 1{
                if item.category?.type == "-"{
                    sum -= item.amount
                }else{
                    sum += item.amount
                }
            }
        }
        return sum
    }
}
