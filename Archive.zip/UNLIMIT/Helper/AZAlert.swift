//
//  AZAlert.swift
//  FinanceApp
//
//  Created by Тимофей on 21.05.2021.
//

import SwiftUI

struct AZAlert: View {
    
    let screenSize = UIScreen.main.bounds
    var title: String = ""
    @Binding var isShown: Bool
    @Binding var text: String
    var onDone: (String) -> Void = { _ in }
    var onCancel: () -> Void = { }
    
    
    var body: some View {
    
        Spacer()
        VStack(spacing: 20) {
            Text(title)
                .font(.headline)
            TextField("", text: $text)
                .textFieldStyle(RoundedBorderTextFieldStyle())
            HStack(spacing: 50) {
                Button("Добавить") {
                    self.isShown = false
                    self.onDone(self.text)
                }
                Button("Отменить") {
                    self.isShown = false
                    self.onCancel()
                }
            }
        }
        .padding()
        .frame(width: screenSize.width * 0.7, height: screenSize.height * 0.3)
        .background(Color.primary_color)
        .clipShape(RoundedRectangle(cornerRadius: 20.0, style: .continuous))
        .offset(y: isShown ? 0 : screenSize.height)
        .animation(.spring())
        .shadow(color: Color.primary_back, radius: 6, x: -9, y: -9)

    }
}
