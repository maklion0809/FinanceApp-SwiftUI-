//
//  getCurrenciesResponse.swift
//  FinanceApp
//
//  Created by Тимофей on 21.05.2021.
//

import Foundation

struct GetCurrenciesRespons {
    typealias JSON = [String: AnyObject]
    let currencies: [Currency]
    
    init(json: Any) throws{
        guard let array = json as? [JSON] else {
            throw NetworkError.failInternerError
        }
        var currencies = [Currency]()
        for dictionary in array{
            guard  let currency = Currency(dict: dictionary) else {
                continue
            }
            currencies.append(currency)
        }
        self.currencies = currencies
    }
}
