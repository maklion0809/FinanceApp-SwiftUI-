//
//  CurrenciesNetworkService.swift
//  FinanceApp
//
//  Created by Тимофей on 21.05.2021.
//

import Foundation

class CurrenciesNetworkService{
    private init() {}
    static func getCurrencies(competion: @escaping(GetCurrenciesRespons)->()){
        guard  let url = URL(string: "https://bank.gov.ua/NBUStatService/v1/statdirectory/exchange?json") else {
        return}
        NetworkService.shared.getData(url: url, completion: { (json) in
            do{
                let response = try GetCurrenciesRespons(json: json)
                competion(response)
            }catch{
                print(error)
            }
        })
    }
}
