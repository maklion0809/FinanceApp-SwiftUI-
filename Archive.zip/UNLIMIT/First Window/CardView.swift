//
//  CardView.swift
//  FinanceApp
//
//  Created by Тимофей on 22.05.2021.
//

import SwiftUI


/// Credit card view
struct CardView: View {
    
    @State var showExpenses = false
    @State var showIncome = false
    
    let wallet: Wallet
    
    let size = UIScreen.main.bounds
    
    
    var flarePosition: UnitPoint = UnitPoint(x: 0.3, y: 0.2)
    var animatableData: UnitPoint {
        get { return flarePosition }
        set { flarePosition = newValue }
    }
    
    
    private let currencyFormatter: NumberFormatter = {
        let currencyFormatter = NumberFormatter()
        currencyFormatter.usesGroupingSeparator = true
        currencyFormatter.numberStyle = .currency
        currencyFormatter.currencySymbol = "$"
        currencyFormatter.locale = Locale(identifier: "en")
        
        return currencyFormatter
    }()
    
    
    
    var body: some View {
        
        VStack {
            VStack{
                Spacer(minLength: 12)
                HStack{
                    Text("\(wallet.title)").foregroundColor(Color.text_primary_color).font(.title3)
                    Spacer()
                }.padding(.leading)
                VStack{
                    Text("\(wallet.balance, specifier: "%.2f")\(wallet.currency?.txt ?? "")").foregroundColor(Color.text_primary_color).font(.title2)
                    Text("ТЕКУЩАЯ СУММА").font(.title3).foregroundColor(Color.init(hex: "828282"))
                }
                HStack{
                    
                    VStack(spacing: 6) {
                        
                        HStack {
                            Spacer()
                            Button(action: {
                                self.showIncome.toggle()
                            }){
                                Image("income_icon").resizable().frame(width: 40.0, height: 40.0).rotationEffect(Angle(degrees: 180))
                            }.fullScreenCover(isPresented: $showIncome){
                                ReportView(isIncome: true, isPresented: $showIncome)
                            }
                        }
                        HStack{
                            Text("ДОХОДЫ").foregroundColor(Color.init(hex: "828282")).padding(.trailing, 12)
                            Spacer()
                        }.padding(.horizontal, 12)
                        HStack {
                            Text("$\(getIncome(), specifier: "%.2f")").foregroundColor(Color.text_primary_color)
                            Spacer()
                        }.padding(.horizontal, 12).padding(.bottom, 12)
                    }
                    
                    
                    
                    Spacer(minLength: 10)
                    
                    
                    VStack(spacing: 6) {
                        HStack {
                            Spacer()
                            Button(action: {
                                self.showExpenses.toggle()
                            }){
                                Image("expense_icon").resizable().frame(width: 40.0, height: 40.0).padding(.trailing, 12).rotationEffect(Angle(degrees: 180))
                            }.fullScreenCover(isPresented: $showExpenses){
                                ReportView(isIncome: false, isPresented: $showExpenses)
                            }
                        }
                        HStack{
                            Text("РАСХОДЫ").foregroundColor(Color.init(hex: "828282"))
                            Spacer()
                        }.padding(.horizontal, 12)
                        HStack {
                            Text("$\(getExpenses(), specifier: "%.2f")").foregroundColor(Color.text_primary_color)
                            Spacer()
                        }.padding(.horizontal, 12).padding(.bottom, 12)
                    }
                }
            }
        }.frame(width: size.width - 50, height: 200).background(Color.secondary_color).cornerRadius(30)
    }
    func getIncome() -> Double{
        var sum = 0.0
        let transactions = wallet.transactions.toArray()
        for item in transactions{
            if item.type == "+"{
                sum += item.amount
            }
        }
        return sum
    }
    func getExpenses() -> Double{
        var sum = 0.0
        let transactions = wallet.transactions.toArray()
        for item in transactions{
            if item.type == "-"{
                sum += item.amount
            }
        }
        return sum
    }
}
