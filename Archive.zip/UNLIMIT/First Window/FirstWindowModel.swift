//
//  FirstViewModel.swift
//  UNLIMIT
//
//  Created by Тимофей on 07.06.2021.
//

import Foundation

class FirstWindowModel: ObservableObject{
    var wallets: [Wallet] = []
    var goal: Goal?
    var debt: Debt?
    init(){
        if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
            if let user = DatabaseManager.shared.getUser(id: userId){
                self.wallets = user.wallets.toArray()
                if user.debts.count != 0{
                    if !user.debts[0].complite{
                        self.debt = user.debts[0]
                    }
                }
                if user.goals.count != 0{
                    if !user.goals[0].complite{
                        self.goal = user.goals[0]
                    }
                }
            }
        }
    }
    func getTotalValue() -> Double {
        var value = Double(0)
        for i in wallets { value += i.balance }
        return value
    }

}
