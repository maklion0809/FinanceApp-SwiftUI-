//
//  IndexCard.swift
//  FinanceApp
//
//  Created by Тимофей on 22.05.2021.
//

import SwiftUI


/// Selected index view
struct IndexView: View {
    
    private var count: Int = 0
    
    // MARK: - Animatable
    
    var selectedIndex: Int = 0
    var animatableData: Int {
        get { return selectedIndex }
        set { selectedIndex = newValue }
    }
    
    
    // MARK: - Body
    
    var body: some View {
        
        let size: CGFloat = 10
        let selectedScaleFactor: CGFloat = 2.5
        
        return
            VStack(spacing: 0) {
                ForEach((0..<count), id: \.self) {
                    RoundedRectangle(cornerRadius: 2)
                        .fill($0 == self.selectedIndex ? Color.primary_back: Color.primary_back)
                        .frame(width: size, height: 2)
                        .scaleEffect(x: $0 == self.selectedIndex ? selectedScaleFactor : 1.0,
                                     y: $0 == self.selectedIndex ? selectedScaleFactor : 1.0,
                                     anchor: .center)
                        .padding(.vertical, ($0 == self.selectedIndex ? 16 : 8))
                }
        }
    }
    
    
    // MARK: - Modifiers
    
    func select(at index: Int, in count: Int) -> Self {
        var indexView = self
        indexView.selectedIndex = index
        indexView.count = count
        return indexView
    }
    
}


private struct IndexViewPreview: View {
    
    let count = 4
    
    @State var index = 0
    
    var body: some View {
        ZStack(alignment: .leading) {
            IndexView() .select(at: index, in: count)
        }
    }
}
