//
//  SettingWallet.swift
//  FinanceApp
//
//  Created by Тимофей on 21.05.2021.
//

import SwiftUI
import Charts

struct DetailedWalletView: View {
    
    @Binding var isPresented: Bool
    
    @State var transactions: [Transaction] = []
    
    @State var wallet: Wallet
    
    private var leadingBarButtonItems: some View {
        Button(action: {
            isPresented = false
        }){
            Image(systemName: "arrow.left").font(.title2).foregroundColor(.primary)
        }
    }
    
    var body: some View {
        NavigationView {
            ZStack{
                Color.primary_color.edgesIgnoringSafeArea(.all)
                VStack{
                    if !wallet.transactions.isEmpty {
                        //"\nВообщем по кашельку - \(getTotalValue())"
                            ChartView(label: "", entries: ChartModel.getTransaction(transactions: getChartModel()))
                        }else{
                            
                        }
                    PrecipitationChart(wallet: wallet).padding(.horizontal, 10)
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarItems(leading: leadingBarButtonItems)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("Детально о \(wallet.title)").font(.headline)
                    
                }
                
            }
        }   .navigationBarColor(backgroundColor: UIColor.primary_color!, tintColor: UIColor.primary_color!)
        .navigationViewStyle(StackNavigationViewStyle())
    }
    private func getChartModel() -> [ChartModel] {
        var sumInc = Double(0)
        var sumExp = Double(0)
        for item in wallet.transactions{
            if item.category?.type == "-"{
                sumExp += item.amount
            }else if item.category?.type == "+"{
                sumInc += item.amount
            }
        }
        print(sumExp)
        print(sumInc)
        let models: [ChartModel] = [ChartModel(transType: "Доходы", transAmount: sumInc), ChartModel(transType: "Расходы", transAmount: sumExp)]
        return models
    }
    func getTotalValue() -> String {
        var value = Double(0)
        for i in transactions {
            if i.category?.type == "-"{
                value -= i.amount
            }else{
                value += i.amount
            }
        }
        return "\(String(format: "%.2f", value))"
    }
}

