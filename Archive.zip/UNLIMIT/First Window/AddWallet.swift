//
//  AddWallet.swift
//  FinanceApp
//
//  Created by Тимофей on 21.05.2021.
//

import SwiftUI

struct AddWallet: View {
    
    @State var isLoading = true
    
    @State var index: Int?
    
    @Environment(\.presentationMode) var presentationMode
    
    @State var showWallet = false

    var auto: Bool = false
    
    @State var currencies: [Currency] = []
    
    @State var selectedCurrencyIndex = false
    
    @State var title = ""
    @State var balance = ""
    @State var currencyText: Currency?
    @State var message = ""
    @State var alert = false
    @State var show = false
        
    private var leadingBarButtonItems: some View {
        Button(action: {
            self.presentationMode.wrappedValue.dismiss()
        }){
            Image(systemName: "arrow.left").font(.title2).foregroundColor(.primary)
        }
    }
    
    var body: some View {
        NavigationView {
            ZStack{
                Color.primary_color.edgesIgnoringSafeArea(.all)
                VStack{
                    
                    if isLoading{
                        
                        ProgressView().progressViewStyle(CircularProgressViewStyle(tint: .primary_back)).scaleEffect(3)
                        
                    }else{
                    
                    ScrollView(showsIndicators: false){
                        
                        VStack(spacing: 12){
                            Image("settingCard").resizable().aspectRatio(contentMode: .fit).frame(width: 200, height: 200, alignment: .center)
                            
                            TextField("Название:", text: $title)
                                .accentColor(Color.text_primary_color)
                                .frame(height: 50).padding(.leading, 16)
                                .background(Color.secondary_color)
                                .cornerRadius(4)
                    
                            TextField("Баланс", text: $balance).accentColor(Color.text_primary_color).frame(height: 50).padding(.leading, 16).background(Color.secondary_color).cornerRadius(4).keyboardType(.decimalPad)
                            
                            DisclosureGroup("\(currencyText?.txt ?? "")", isExpanded: $selectedCurrencyIndex){
                                VStack{
                                    ForEach(currencies, id: \.r030){ currency in
                                        HStack{
                                            Text("\(currency.txt)")
                                            Spacer()
                                            Text("\(currency.cc)")
                                            
                                        }.onTapGesture {
                                            self.currencyText = currency
                                            withAnimation{
                                                self.selectedCurrencyIndex.toggle()
                                            }
                                        }
                                    }.accentColor(Color.text_primary_color).frame(height: 50)
                                }
                            }.accentColor(Color.text_primary_color).padding(.vertical, 10).padding(.horizontal, 16).background(Color.secondary_color).cornerRadius(4)
                            
                        }
                        if auto != true{
                            Button(action: {
                                if let actualAmount = Double(self.balance){
                                    let wallet = Wallet(id: UUID().uuidString, title: title, balance: actualAmount, currency: currencyText!)
                                    if let i = index{
                                        DatabaseManager.shared.updateWalletToUser(id: i, wallet: wallet)
                                    }else{
                                        DatabaseManager.shared.addWalletToUser(wallet)
                                    }
                                    self.presentationMode.wrappedValue.dismiss()
                                }else{
                                    self.message = "Некоректное значение"
                                    self.alert.toggle()
                                }
                            }) {
                        
                                RoundedRectangle(cornerRadius: 5).frame(width: 250, height: 50).foregroundColor(Color.black).overlay(
                                    Text(index == nil ? "Создать кошелек" : "Cохранить изменения").foregroundColor(.white)
                                )
                            }.padding()
                        }else{
                            Button(action: {
                                    if let actualAmount = Double(self.balance){
                                        let wallet = Wallet(id: UUID().uuidString, title: title, balance: actualAmount, currency: currencyText!)
                                        if let i = index{
                                            DatabaseManager.shared.updateWalletToUser(id: i, wallet: wallet)
                                        }else{
                                            DatabaseManager.shared.addWalletToUser(wallet)
                                        }
                                        self.showWallet.toggle()
                                    }else{
                                        self.message = "Некоректное значение"
                                        self.alert.toggle()
                                    }
                            }) {
                        
                                RoundedRectangle(cornerRadius: 5).frame(width: 250, height: 50).foregroundColor(Color.primary_back).overlay(
                                    Text(index == nil ? "Создать кошелек": "Cохранить изменения").foregroundColor(.primary_color)
                                )
                            }.padding().fullScreenCover(isPresented: $showWallet){
                                Security(newPinCode: true)
                            }
                        }
                    }
                    }
                }
            }
            .alert(isPresented: $alert) {
                Alert(title: Text("Ошибка!"), message: Text(self.message), dismissButton: .default(Text("Ok")))
            }
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarItems(leading: (auto == true) ? nil : leadingBarButtonItems)
                  .toolbar {
                      ToolbarItem(placement: .principal) {
                        Text(index == nil ? "Создать кошелек" : "Изменить кошелек").font(.headline)

                      }
                    
                  }
        }    .navigationBarColor(backgroundColor: UIColor.primary_color!, tintColor: UIColor.primary_color!).dismissKeyboardOnTap()
        .navigationViewStyle(StackNavigationViewStyle()).onAppear{
            CurrenciesNetworkService.getCurrencies{ (response) in
                self.currencies = response.currencies
               // if index == nil{
                    self.currencyText = response.currencies[0]
               // }
                isLoading = false
            }
        }
    }
}

