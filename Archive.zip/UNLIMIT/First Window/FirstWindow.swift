//
//  FirstWindow.swift
//  FinanceApp
//
//  Created by Тимофей on 21.05.2021.
//

import SwiftUI

struct FirstWindow: View {
    
    @State private var showingDetailedGoal = false
    @State private var showingDetailedDebt = false
    
    let transparencyAngle = 50.0
    let card3DRotationAngle: Double = 14
    
    @State private var currentIndex = UserDefaults.standard.integer(forKey: "ChooseWallet")
    private var nextIndex: Int { return (currentIndex + 1) % viewModel.wallets.count }
    private var prevIndex: Int { return (currentIndex + viewModel.wallets.count - 1) % viewModel.wallets.count }
    
    /// card selection rotation angle
    @State private var angle: Angle = .zero
    
    /// card selection rotation anchor
    private let cardsRotationAnchor = UnitPoint(x: 1.5, y: 0.5)
    
    @State private var showCardMenu = false
    @State private var showWallet = false{
        willSet{
            
        }
    }
    
    @State private var indexView = IndexView()
    
    @State private var menuItemSize: CGFloat = 66
    
    private func angle(forWidth width: CGFloat, offset: CGSize) -> Angle {
        return Angle(radians:
                        Double(-atan(offset.height/(width*cardsRotationAnchor.x-width/2)))
        )
    }
    
    
    private var trailingBarButtonItems: some View {
        Button(action: {
            withAnimation{
                self.showWallet = true
            }
        }){
            Image(systemName: "plus").font(.title2).foregroundColor(.primary)
        }.fullScreenCover(isPresented: $showWallet) {
            AddWallet()
        }
    }
    
    @StateObject var viewModel: FirstWindowModel
    
    var body: some View {
        
        UIApplication.shared.windows.first?.rootViewController?.view.overrideUserInterfaceStyle = UserDefaults.standard.bool(forKey: "ColorApp") ? .dark : .light
        
        var visibleCard = CardView(wallet: self.viewModel.wallets[self.currentIndex])
        visibleCard.flarePosition = showCardMenu ?
            UnitPoint(x: 1.0, y: 0.5) : UnitPoint(x: 0.3, y: 0.2)
        
        return NavigationView {
            ZStack{
                Color.primary_color.edgesIgnoringSafeArea(.all)
                VStack{
                    
                    
                    HStack{
                        
                        Spacer(minLength: 50)
                        
                        VStack(spacing: 12) {
                            HStack{
                                Spacer()
                                Text("Общий счет:").foregroundColor(Color.text_primary_color).font(.system(size: 30))
                                Spacer()
                            }
                            HStack{
                                Spacer()
                                Text("\(viewModel.getTotalValue(), specifier: "%.2f")").foregroundColor(Color.text_primary_color).font(.system(size: 30))
                                Spacer()
                            }
                        }
                        Spacer(minLength: 15)
                    }
                    
                    
                    Spacer(minLength: 12)
                    
                    GeometryReader { geometry in
                        
                        VStack {
                            
                            ZStack(alignment: .leading) {
                                // selected card index view
                                self.indexView
                                    .onAppear {
                                        self.indexView = self.indexView
                                            .select(at: self.currentIndex,
                                                    in: self.viewModel.wallets.count)
                                    }
                                
                                HStack(alignment: .center, spacing: 0) {
                                    
                                    Spacer(minLength: 15)
                                    
                                    // cards container
                                    ZStack {
                                        
                                        CardView(wallet: self.viewModel.wallets[self.nextIndex])
                                            // next card is at 90 degrees
                                            // opacity depends on the angle
                                            .opacity(1-abs(self.angle.degrees+90)/self.transparencyAngle)
                                            .rotationEffect(Angle(degrees: self.angle.degrees+90),
                                                            anchor: self.cardsRotationAnchor)
                                        
                                        visibleCard
                                            // visible card is at 0 degrees
                                            // opacity depends on the angle
                                            .opacity(1-abs(self.angle.degrees)/self.transparencyAngle)
                                            .rotationEffect(self.angle,
                                                            anchor: self.cardsRotationAnchor)
                                        
                                        CardView(wallet: self.viewModel.wallets[self.prevIndex])
                                            // previous card is at -90 degrees
                                            // opacity depends on the angle
                                            .opacity(1-abs(self.angle.degrees-90)/self.transparencyAngle)
                                            .rotationEffect(Angle(degrees: self.angle.degrees-90),
                                                            anchor: self.cardsRotationAnchor)
                                    }
                                    .padding(.horizontal, 18)
                                    // 3D rotation effect based on showCardMenu prop
                                    .rotation3DEffect(.degrees(self.showCardMenu ? self.card3DRotationAngle : 0),
                                                      axis: (x: 0, y: -1, z: 0),
                                                      anchor: .trailing,
                                                      perspective: 1)
                                    .padding(.leading, self.showCardMenu ? -self.menuItemSize : 0)
                                    // cards selection rotation gesture
                                    .gesture(DragGesture()
                                                .onChanged {
                                                    // hide menu if needed
                                                    if self.showCardMenu {
                                                        withAnimation(.easeInOut(duration: 0.2)) {
                                                            self.showCardMenu = false
                                                        }
                                                    }
                                                    
                                                    self.angle =
                                                        self.angle(forWidth: geometry.size.width,
                                                                   offset: $0.translation)
                                                }
                                                .onEnded { _ in
                                                    self.updateCardSelection(for: self.angle)
                                                })
                                    // show menu tap gesture
                                    .gesture(TapGesture().onEnded {
                                        withAnimation(.easeInOut(duration: 0.2)) {
                                            self.showCardMenu.toggle()
                                        }
                                    })
                                    // getting height to calculate menu item size. hack :)
                                    .overlay(GeometryReader { g in
                                        Color.clear.onAppear {
                                            self.menuItemSize = g.size.height / 3
                                        }
                                    })
                                    
                                    // card menu
                                    if self.showCardMenu {
                                        CardMenu(wallet: viewModel.wallets[currentIndex], size: self.menuItemSize)
                                            .transition(AnyTransition
                                                            .move(edge: .trailing)
                                                            .combined(with: .opacity))
                                    }
                                }
                            }
                        }
                        .padding(.bottom, 16)
                    }
                    VStack(alignment: .leading, spacing: 15){
                        Group{
                            Text("Главная цель").foregroundColor(.gray)
                            Divider()
                            Spacer(minLength: 20)
                            if let goal = viewModel.goal{
                                GoalItemView(goal: goal)
                                    .onTapGesture{
                                        self.showingDetailedGoal.toggle()
                                    }.fullScreenCover(isPresented: $showingDetailedGoal){
                                        DetailedGoalView(isPresented: $showingDetailedGoal, goal: goal, index: 0)
                                    }
                            }else{
                                HStack{
                                    Spacer()
                                    VStack{
                                        Text("Еще нет целей!").foregroundColor(Color.text_primary_color)
                                        Text("Добавьте цель, и она появится здесь").foregroundColor(Color.text_secondary_color).padding(.top, 2)
                                    }
                                    Spacer()
                                }
                            }
                            Spacer(minLength: 20)
                        }
                        Group{
                            Text("Основной долг").foregroundColor(.gray)
                            Divider()
                            Spacer(minLength: 20)
                            if let debt = viewModel.debt{
                                DebtItemView(debt: debt).onTapGesture{
                                    self.showingDetailedDebt.toggle()
                                }.fullScreenCover(isPresented: $showingDetailedDebt){
                                    DetailedDebtView(isPresented: $showingDetailedDebt, debt: debt, index: 0)
                                }
                            }else{
                                HStack{
                                    Spacer()
                                    VStack{
                                        Text("Еще нет долгов!").foregroundColor(Color.text_primary_color)
                                        Text("Добавьте долг, и он появится здесь").foregroundColor(Color.text_secondary_color).padding(.top, 2)
                                    }
                                    Spacer()
                                }
                            }
                            Spacer(minLength: 20)
                        }
                    }
                }
            }
            .navigationBarTitleDisplayMode(.inline).navigationBarItems(trailing: trailingBarButtonItems)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("Cводка").font(.headline)
                }
            }
        }    .navigationBarColor(backgroundColor: UIColor.primary_color!, tintColor: UIColor.primary_color!)
    }
    
    
    func updateCardSelection(for angle: Angle) {
        let duration = TimeInterval(0.45)
        
        var newIndex = currentIndex
        
        withAnimation(.easeOut(duration: duration)) {
            switch self.angle.degrees {
            case 15...:
                // show previous card
                newIndex = self.prevIndex
                self.angle.degrees = 90
                
            case  ...(-15):
                // show next card
                newIndex = self.nextIndex
                self.angle.degrees = -90
                
            default:
                self.angle = .zero
            }
            
            self.indexView =
                self.indexView.select(at: newIndex, in: self.viewModel.wallets.count)
            
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + duration) {
            self.currentIndex = newIndex
            UserDefaults.standard.setValue(self.currentIndex, forKey: "ChooseWallet")
            self.angle = .zero
        }
    }
    
}




