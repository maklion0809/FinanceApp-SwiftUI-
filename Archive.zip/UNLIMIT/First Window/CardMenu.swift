//
//  CardMenu.swift
//  FinanceApp
//
//  Created by Тимофей on 22.05.2021.
//

import Foundation
import SwiftUI

struct CardMenu : View {
    
    @State var showConfirm = false
    
    @State var showingLock: Bool = false
    @State var showingPencil: Bool = false
    
    @State var showingAddWallet: Bool = false

    @State var wallet: Wallet
    
    let size: CGFloat
    
    var body: some View {
        VStack(spacing: 0){
            Button(action: {
                self.showingLock.toggle()
            }){
                Image(systemName: "doc.plaintext")
                    .font(.system(size: 30.0))
                    .foregroundColor(Color.primary_color)
                    .frame(width: size, height: size)
            }.fullScreenCover(isPresented: $showingLock){
                DetailedWalletView(isPresented: $showingLock, wallet: wallet)
            }
            
            Button(action: {
                self.showingPencil.toggle()
            }){
                Image(systemName: "pencil.and.ellipsis.rectangle")
                    .font(.system(size: 30.0))
                    .foregroundColor(Color.primary_color)
                    .frame(width: size, height: size)
            }.fullScreenCover(isPresented: $showingPencil) {
                AddWallet(index: UserDefaults.standard.object(forKey: "ChooseWallet") as? Int, title: wallet.title, balance: String(wallet.balance), currencyText: wallet.currency)
            }
            
            Button(action: {
                self.showConfirm.toggle()
            }){
                Image(systemName: "trash")
                    .font(.system(size: 30.0))
                    .foregroundColor(Color.primary_color)
                    .frame(width: size, height: size)
            }.fullScreenCover(isPresented: $showingAddWallet){
                AddWallet(auto: true)
            }
 
        }
        .background(Color.primary_back)
        .cornerRadius(8).alert(isPresented: $showConfirm) {
            Alert(title: Text("Удалить"), message: Text("Вы уверены?"),
                  primaryButton: .cancel(Text("Отмена")),
                  secondaryButton: .destructive(Text("Удалить")) {
                    DispatchQueue.main.asyncAfter(deadline: .now()) {
                        if let walletId = UserDefaults.standard.object(forKey: "ChooseWallet"){
                            DatabaseManager.shared.deleteWalletToUser(id: walletId as! Int)
                            UserDefaults.standard.setValue(0, forKey: "ChooseWallet")
                            if let userId = UserDefaults.standard.string(forKey: "ChooseUser"){
                                if let user = DatabaseManager.shared.getUser(id: userId){
                                    if user.wallets.count == 0{
                                        self.showingAddWallet.toggle()
                                    }
                                }
                            }
                        }
                    }
                  })
        }
    }
    
}
