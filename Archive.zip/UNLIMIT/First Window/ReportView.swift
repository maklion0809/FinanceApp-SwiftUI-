//
//  ExpensesReportView.swift
//  UNLIMIT
//
//  Created by Тимофей on 09.06.2021.
//

import SwiftUI

struct ReportView: View {
    
    var isIncome: Bool
    
    @State var transactions: [Transaction] = []
    
    @Binding var isPresented: Bool
    
    private var leadingBarButtonItems: some View {
        Button(action: {
            isPresented = false
        }){
            Image(systemName: "arrow.left").font(.title2).foregroundColor(.primary)
        }
    }
    
    var body: some View {
        NavigationView {
            ZStack{
                Color.primary_color.edgesIgnoringSafeArea(.all)
                VStack{
                    if !transactions.isEmpty {
                        // Вообщем по \(isIncome ? "доходам" : "расходам") - \(getTotalValue())
                            ChartView(label: "", entries: ChartModel.getTransaction(transactions: getChartModel()))
                        List{
                            ForEach(transactions){ item in
                                TransactionView(transactions: item)
                            }
                        }
                    }else{
                        LottieView(animType: .empty_face).frame(width: 300, height: 300).transition( AnyTransition.asymmetric(insertion: .scale, removal: .opacity))
                        VStack {
                            Text("Еще нет транзакций!").foregroundColor(Color.text_primary_color)
                            Text("Здесь отображается статистика").foregroundColor(Color.text_secondary_color).padding(.top, 2)
                        }.padding(.horizontal).transition( AnyTransition.asymmetric(insertion: .scale, removal: .opacity))
                        Spacer()
                    }
                    
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarItems(leading: leadingBarButtonItems)
                  .toolbar {
                      ToolbarItem(placement: .principal) {
                              Text("Отчет по \(isIncome ? "доходам" : "расходам")").font(.headline)

                      }
                    
                  }
        }   .navigationBarColor(backgroundColor: UIColor.primary_color!, tintColor: UIColor.primary_color!)
        .navigationViewStyle(StackNavigationViewStyle()).onAppear{
            if let indexUser = UserDefaults.standard.string(forKey: "ChooseUser"){
                if let user = DatabaseManager.shared.getUser(id: indexUser){
                    if let indexWallet = UserDefaults.standard.object(forKey: "ChooseWallet"){
                        let transactionBudget = user.wallets[indexWallet as! Int].transactions.toArray()
                        for item in transactionBudget{
                            if isIncome{
                                if item.type == "+"{
                                    transactions.append(item)
                                }
                            }else{
                                if item.type == "-"{
                                    transactions.append(item)
                                }
                            }
                        }
                    }
                }
            }

        }
    }
    func getTotalValue() -> String {
        var value = Double(0)
        for i in transactions { value += i.amount }
        return "\(String(format: "%.2f", value))"
    }
    private func getChartModel() -> [ChartModel] {
        var trans = [String: Double]()
        for item in transactions{
            guard let title = item.category?.title else { continue }
            if let value = trans[title] {
                trans[title] = value + item.amount
            } else { trans[title] = item.amount }
        }
        
        var models = [ChartModel]()
        for i in trans{
            models.append(ChartModel(transType: i.key , transAmount: i.value))
        }
        return models
    }
}

