//
//  Transaction.swift
//  FinanceApp
//
//  Created by Тимофей on 24.05.2021.
//

import RealmSwift
import Foundation

class Transaction: Object, ObjectKeyIdentifiable{
    
    @objc dynamic var id: String = ""
    @objc dynamic var amount: Double = 0.00
    @objc dynamic var category: Category?
    @objc dynamic var type: String = ""
    @objc dynamic var date: Date = Date()
    @objc dynamic var note: String?
    
    
    convenience init(
        id: String = UUID().uuidString,
        amount: Double,
        category: Category?,
        type: String,
        date: Date,
        note: String?)
    {
        self.init()
        self.id = id
        self.amount = amount
        self.category = category
        self.type = type
        self.date = date
        self.note = note
    }
    
    override static func primaryKey() -> String? {
        return "id"
    }
}
