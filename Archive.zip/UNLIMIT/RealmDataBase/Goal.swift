//
//  Goal.swift
//  FinanceApp
//
//  Created by Тимофей on 24.05.2021.
//

import RealmSwift
import Foundation

class Goal: Object, ObjectKeyIdentifiable{
    
    @objc dynamic var id: String = ""
    @objc dynamic var title: String = ""
    @objc dynamic var amount: Double = 0.00
    @objc dynamic var inMonth: Double = 0.00
    @objc dynamic var complite: Bool = false
    @objc dynamic var endDate: Date = Date()
    @objc dynamic var monthes: Double = 0.0
    @objc dynamic var note: String?
    

    convenience init(
        id: String = UUID().uuidString,
        title: String,
        amount: Double,
        inMonth: Double,
        complite: Bool,
        endDate: Date,
        monthes: Double,
        note: String?)
    {
        self.init()
        self.id = id
        self.title = title
        self.amount = amount
        self.inMonth = inMonth
        self.complite = complite
        self.endDate = endDate
        self.monthes = monthes
        self.note = note
    }
    
    override static func primaryKey() -> String? {
        return "id"
    }
}
