//
//  Category.swift
//  FinanceApp
//
//  Created by Тимофей on 24.05.2021.
//

import RealmSwift
import Foundation

class Category: Object, ObjectKeyIdentifiable{
    
    @objc dynamic var id: String = ""
    @objc dynamic var title: String = ""
    @objc dynamic var type: String = ""
    @objc dynamic var system: Bool = true
    
    convenience init(
        id: String = UUID().uuidString,
        title: String,
        type: String,
        system: Bool)
    {
        self.init()
        self.id = id
        self.title = title
        self.type = type
        self.system = system
    }
    override static func primaryKey() -> String? {
        return "id"
    }
    
}

