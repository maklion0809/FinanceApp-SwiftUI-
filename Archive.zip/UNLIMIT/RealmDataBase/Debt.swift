//
//  Debt.swift
//  FinanceApp
//
//  Created by Тимофей on 24.05.2021.
//

import RealmSwift
import Foundation

class Debt: Object, ObjectKeyIdentifiable{
    
    @objc dynamic var id: String = ""
    @objc dynamic var title: String = ""
    @objc dynamic var amount: Double = 0
    @objc dynamic var type: String = ""
    @objc dynamic var startDate: Date = Date()
    @objc dynamic var endDate: Date = Date()
    @objc dynamic var note: String?
    @objc dynamic var complite: Bool = false
        
    convenience init(
        id: String = UUID().uuidString,
        title: String,
        amount: Double,
        type: String,
        startDate: Date,
        endDate: Date,
        note: String,
        complite: Bool)
    {
        self.init()
        self.id = id
        self.title = title
        self.amount = amount
        self.type = type
        self.startDate = startDate
        self.endDate = endDate
        self.note = note
        self.complite = complite
    }
    
    override static func primaryKey() -> String? {
        return "id"
    }
}


