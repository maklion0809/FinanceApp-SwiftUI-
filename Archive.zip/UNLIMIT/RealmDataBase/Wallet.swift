//
//  Wallet.swift
//  FinanceApp
//
//  Created by Тимофей on 24.05.2021.
//
import RealmSwift
import Foundation

class Wallet: Object, ObjectKeyIdentifiable {
    
    @objc dynamic var id: String = ""
    @objc dynamic var title: String = ""
    @objc dynamic var balance: Double = 0.00
    var currency: Currency?
    var transactions = List<Transaction>()
    var budgets = List<Budget>()
    
        
    convenience init(
        id: String = UUID().uuidString,
        title: String,
        balance: Double,
        currency: Currency,
        transactions: [Transaction] = [],
        budgets: [Budget] = [])
    {
        self.init()
        self.id = id
        self.title = title
        self.balance = balance
        self.currency = currency
        self.transactions.append(objectsIn: transactions)
        self.budgets.append(objectsIn: budgets)
    }
    
    override static func primaryKey() -> String? {
        return "id"
    }
}
