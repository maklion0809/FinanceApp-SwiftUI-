//
//  User.swift
//  FinanceApp
//
//  Created by Тимофей on 24.05.2021.
//
import RealmSwift
import Foundation

class User: Object, ObjectKeyIdentifiable{
    
    @objc dynamic var id: String = ""
    @objc dynamic var email: String = ""
    @objc dynamic var password: String = ""
    var categories = List<Category>()
    var wallets = List<Wallet>()
    var debts = List<Debt>()
    var goals = List<Goal>()
    
    convenience init(
        id: String,
        email: String,
        password: String,
        categories: [Category] = [],
        wallets: [Wallet] = [],
        debts: [Debt] = [],
        goals: [Goal] = []
    ){
        self.init()
        self.id = id
        self.email = email
        self.password = password
        self.wallets.append(objectsIn: wallets)
        self.debts.append(objectsIn: debts)
        self.goals.append(objectsIn: goals)
        self.categories.append(objectsIn: categories)
    }
    
    override static func primaryKey() -> String? {
      "id"
    }
}

