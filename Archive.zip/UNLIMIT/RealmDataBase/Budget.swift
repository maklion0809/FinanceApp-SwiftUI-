//
//  Budget.swift
//  FinanceApp
//
//  Created by Тимофей on 24.05.2021.
//

import RealmSwift
import Foundation

class Budget: Object, ObjectKeyIdentifiable{
    
    @objc dynamic var id: String = ""
    @objc dynamic var title: String = ""
    @objc dynamic var amount: Double = 0
    @objc dynamic var startDate: Date = Date()
    @objc dynamic var endDate: Date = Date()
    var categories = List<Category>()
        
    convenience init(
        id: String = UUID().uuidString,
        title: String,
        amount: Double,
        startDate: Date,
        endDate: Date,
        categories: [Category] = [])
    {
        self.init()
        self.id = id
        self.title = title
        self.amount = amount
        self.startDate = startDate
        self.endDate = endDate
        self.categories.append(objectsIn: categories)
    }
    
    override static func primaryKey() -> String? {
        return "id"
    }
    
}
